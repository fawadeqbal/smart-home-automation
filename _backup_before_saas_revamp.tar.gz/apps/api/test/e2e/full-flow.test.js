/**
 * End-to-end: the real API (built: `pnpm build`), the real database and broker, a fake board
 * (tools/fake-node) and a Socket.IO client, through the whole workflow:
 *   setup -> board discovered -> adopt -> devices + pins + button -> command with ack ->
 *   sensor readings -> live updates -> family member rights -> wall button -> board offline.
 *
 * Needs Postgres and Mosquitto running (pnpm infra:up) and python + paho-mqtt.
 * Stop `pnpm dev` first: a second API on the same database and broker would record every message twice.
 * WARNING: empties the database it points at. Run:  pnpm --filter @home/api test:e2e
 */
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { spawn } = require('node:child_process');
const path = require('node:path');
const { io } = require('socket.io-client');

const ROOT = path.resolve(__dirname, '../../../..');
const NODE_ID = 'esp-e2e01';
let app, base, fake, prisma;

class Client {
  constructor() { this.cookies = new Map(); }
  get cookieHeader() { return [...this.cookies].map(([k, v]) => `${k}=${v}`).join('; '); }
  async req(method, url, body) {
    const res = await fetch(base + url, {
      method,
      headers: { 'Content-Type': 'application/json', Cookie: this.cookieHeader },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
    for (const c of res.headers.getSetCookie()) {
      const [pair] = c.split(';');
      const [k, v] = pair.split('=');
      if (v) this.cookies.set(k, v); else this.cookies.delete(k);
    }
    const text = await res.text();
    return { status: res.status, body: text ? JSON.parse(text) : null };
  }
  get(u) { return this.req('GET', u); }
  post(u, b) { return this.req('POST', u, b ?? {}); }
  patch(u, b) { return this.req('PATCH', u, b); }
  put(u, b) { return this.req('PUT', u, b); }
  del(u) { return this.req('DELETE', u); }
}

async function until(what, fn, timeoutMs = 8000) {
  const end = Date.now() + timeoutMs;
  for (;;) {
    const value = await fn();
    if (value) return value;
    if (Date.now() > end) throw new Error(`Timed out waiting for: ${what}`);
    await new Promise((r) => setTimeout(r, 150));
  }
}

before(async () => {
  process.env.COMMAND_TIMEOUT_MS = '2000';
  process.env.PUBLIC_API_URL = 'http://127.0.0.1:4555'; // where the fake board downloads firmware
  const { createApp } = require('../../dist/main.js');
  const { PrismaClient } = require('@prisma/client');
  prisma = new PrismaClient();
  await prisma.$executeRawUnsafe('TRUNCATE "Home", "User", "Node", "AuditLog", "FirmwareImage" CASCADE');
  app = await createApp();
  await app.listen(4555, '127.0.0.1');
  base = `${await app.getUrl()}/api`.replace('[::1]', '127.0.0.1');
});

after(async () => {
  fake?.kill('SIGKILL');
  // Leave no retained messages from the test board on the broker.
  const mqtt = require('mqtt');
  const client = await mqtt.connectAsync(process.env.MQTT_URL ?? 'mqtt://localhost:1883',
    { username: 'api', password: process.env.MQTT_API_PASSWORD });
  for (const t of ['announce', 'status', 'config', 'devices/bulb/state', 'devices/room_climate/state']) {
    await client.publishAsync(`home/v1/nodes/${NODE_ID}/${t}`, '', { retain: true, qos: 1 });
  }
  await client.endAsync();
  await app?.close();
  await prisma?.$disconnect();
});

const owner = new Client();
const member = new Client();
const state = {};

test('first run: setup creates the home and signs the owner in', async () => {
  assert.deepEqual((await owner.get('/auth/status')).body, { setupNeeded: true });
  const res = await owner.post('/auth/setup', { homeName: 'Test home', name: 'Fawad', email: 'Owner@Example.com', password: 'secret123' });
  assert.equal(res.status, 201);
  assert.equal(res.body.role, 'OWNER');
  assert.equal(res.body.email, 'owner@example.com');
  assert.equal((await owner.post('/auth/setup', { homeName: 'x', name: 'x', email: 'x@x.com', password: 'secret123' })).status, 409);
  assert.equal((await new Client().get('/devices')).status, 401);
  const rooms = (await owner.get('/rooms')).body;
  state.livingRoom = rooms.find((r) => r.name === 'Living room').id;
});

test('a new board announces itself and is adopted', async () => {
  const env = { ...process.env };
  fake = spawn('python3', [path.join(ROOT, 'tools/fake-node/fake_node.py'), '--id', NODE_ID, '--keepalive', '2',
    '--password', process.env.MQTT_NODE_PASSWORD ?? ''], { env, stdio: ['pipe', 'pipe', 'inherit'] });
  fake.stdout.on('data', (d) => { state.fakeLog = (state.fakeLog ?? '') + d; });

  const pending = await until('board listed', async () => (await owner.get('/nodes')).body.find((n) => n.id === NODE_ID));
  assert.equal(pending.status, 'PENDING');
  await until('board online', async () => (await owner.get('/nodes')).body.find((n) => n.id === NODE_ID)?.online);

  assert.equal((await owner.post(`/nodes/${NODE_ID}/adopt`, { name: 'Living room board', board: 'WEMOS_D1_MINI' })).status, 204);
  const node = await until('config applied', async () => {
    const n = (await owner.get('/nodes')).body.find((x) => x.id === NODE_ID);
    return n.status === 'ADOPTED' && n.appliedRev === n.configRev ? n : null;
  });
  assert.equal(node.name, 'Living room board');
});

test('devices and buttons are validated against the board pin rules', async () => {
  const bad = await owner.post(`/nodes/${NODE_ID}/devices`, { name: 'Bad', type: 'switch', pin: 7 });
  assert.equal(bad.status, 400);
  assert.match(bad.body.message, /GPIO 7 cannot be used/);
  assert.equal((await owner.post(`/nodes/${NODE_ID}/devices`, { name: 'Lamp', type: 'switch', pin: 16, settings: { x: 1 } })).status, 400);

  const bulb = await owner.post(`/nodes/${NODE_ID}/devices`, {
    name: 'Bulb', type: 'switch', pin: 5, activeLow: true, roomId: state.livingRoom, aliases: ['batti'],
  });
  assert.equal(bulb.status, 201, JSON.stringify(bulb.body));
  assert.equal(bulb.body.key, 'bulb');
  assert.equal(bulb.body.pinLabel, 'D1 (GPIO 5)');
  state.bulb = bulb.body.id;

  const dup = await owner.post(`/nodes/${NODE_ID}/devices`, { name: 'Fan', type: 'switch', pin: 5 });
  assert.match(dup.body.message, /already used by "Bulb"/);

  const sensor = await owner.post(`/nodes/${NODE_ID}/devices`, {
    name: 'Room climate', type: 'dht', pin: 4, roomId: state.livingRoom, settings: { model: 'dht22', intervalSec: 5 },
  });
  assert.equal(sensor.status, 201, JSON.stringify(sensor.body));
  state.sensor = sensor.body.id;

  assert.equal((await owner.post(`/nodes/${NODE_ID}/inputs`, { type: 'toggle_button', pin: 14, targetId: state.sensor })).status, 400);
  const button = await owner.post(`/nodes/${NODE_ID}/inputs`, { type: 'toggle_button', pin: 14, targetId: state.bulb });
  assert.equal(button.status, 201, JSON.stringify(button.body));

  await until('board applied the new config', async () => {
    const n = (await owner.get('/nodes')).body.find((x) => x.id === NODE_ID);
    return n.appliedRev === n.configRev && !n.configError;
  });
});

test('a command is confirmed by the board and pushed live', async () => {
  const socket = io(base.replace('/api', ''), { extraHeaders: { Cookie: owner.cookieHeader }, transports: ['websocket'] });
  const events = [];
  socket.on('device.state', (e) => events.push(e));
  await new Promise((resolve, reject) => { socket.on('ready', resolve); socket.on('auth.error', reject); });

  const res = await owner.post(`/devices/${state.bulb}/commands`, { on: true });
  assert.equal(res.status, 200, JSON.stringify(res.body));
  assert.deepEqual(res.body.state, { on: true });
  assert.equal(res.body.source, 'remote');
  await until('live update', () => events.find((e) => e.id === state.bulb && e.state.on === true));
  assert.equal((await owner.post(`/devices/${state.sensor}/commands`, { on: true })).status, 400);
  assert.equal((await owner.post(`/devices/${state.bulb}/commands`, { on: 'yes' })).status, 400);

  const climate = await until('sensor reading', async () => {
    const d = (await owner.get(`/devices/${state.sensor}`)).body;
    return typeof d.state?.temperature === 'number' ? d : null;
  });
  assert.equal(climate.source, 'sensor');
  const cmd = await prisma.command.findFirst({ where: { deviceId: state.bulb } });
  assert.equal(cmd.status, 'ACKED');
  socket.close();
});

test('live logs show what the board printed and what the server did', async () => {
  const socket = io(base.replace('/api', ''), { extraHeaders: { Cookie: owner.cookieHeader }, transports: ['websocket'] });
  const live = [];
  socket.on('node.log', (e) => live.push(e));
  await new Promise((resolve) => socket.on('ready', resolve));
  await owner.post(`/devices/${state.bulb}/commands`, { toggle: true });
  await until('live log lines', () => live.some((e) => e.nodeId === NODE_ID && e.entry.source === 'board'));
  const lines = (await owner.get(`/nodes/${NODE_ID}/logs`)).body;
  assert.ok(lines.some((l) => l.source === 'board' && /Command for bulb/.test(l.msg)), 'board line');
  assert.ok(lines.some((l) => l.source === 'server' && /Bulb confirmed/.test(l.msg)), 'server line');
  assert.ok(lines.some((l) => l.source === 'server' && /Sent configuration rev/.test(l.msg)), 'config line');
  assert.equal((await member.get(`/nodes/${NODE_ID}/logs`)).status, 401);
  socket.close();
});

test('family members only see and do what their room rights allow', async () => {
  const invite = await owner.post('/invites', { email: 'kid@example.com', role: 'MEMBER' });
  assert.equal(invite.status, 201);
  assert.deepEqual((await member.get(`/invites/${invite.body.token}`)).body.email, 'kid@example.com');
  const accepted = await member.post(`/invites/${invite.body.token}/accept`, { name: 'Ali', password: 'kidpass123' });
  assert.equal(accepted.status, 201);
  assert.equal((await member.post(`/invites/${invite.body.token}/accept`, { name: 'Ali', password: 'kidpass123' })).status, 410);

  assert.deepEqual((await member.get('/devices')).body, []);
  assert.equal((await member.post(`/devices/${state.bulb}/commands`, { on: false })).status, 404);
  assert.equal((await member.get('/nodes')).status, 403);

  await owner.put(`/users/${accepted.body.id}/rooms`, { rooms: [{ roomId: state.livingRoom, access: 'VIEW' }] });
  assert.equal((await member.get('/devices')).body.length, 2);
  assert.equal((await member.post(`/devices/${state.bulb}/commands`, { on: false })).status, 403);

  await owner.put(`/users/${accepted.body.id}/rooms`, { rooms: [{ roomId: state.livingRoom, access: 'CONTROL' }] });
  const off = await member.post(`/devices/${state.bulb}/commands`, { on: false });
  assert.equal(off.status, 200);
  assert.equal(off.body.state.on, false);
  assert.equal((await member.patch(`/devices/${state.bulb}`, { name: 'Lamp' })).status, 403);
  assert.equal((await member.del(`/devices/${state.bulb}`)).status, 403);

  const cmd = await prisma.command.findFirst({ where: { deviceId: state.bulb, userId: accepted.body.id } });
  assert.equal(cmd.channel, 'web');
});

test('the wall button on the board is recorded as a button press', async () => {
  fake.stdin.write('press D5\n');
  const bulb = await until('button press seen', async () => {
    const d = (await owner.get(`/devices/${state.bulb}`)).body;
    return d.state?.on === true && d.source === 'button' ? d : null;
  });
  assert.equal(bulb.state.on, true);
  const history = (await owner.get(`/devices/${state.bulb}/history`)).body;
  assert.deepEqual(history.slice(0, 2).map((h) => h.source), ['button', 'remote']);
});

test('scenes run at once; timers run later with their creator\'s rights', async () => {
  // scene: bulb off
  const scene = await owner.post('/scenes', { name: 'Good night', actions: [{ deviceId: state.bulb, on: false }] });
  assert.equal(scene.status, 201);
  const ran = await owner.post(`/scenes/${scene.body.id}/run`);
  assert.equal(ran.status, 201);
  assert.equal(ran.body.ok, true);
  assert.equal((await owner.get(`/devices/${state.bulb}`)).body.state.on, false);

  // a member may not automate a device they can only view
  const kid = new Client();
  await kid.post('/auth/login', { email: 'kid@example.com', password: 'kidpass123' });
  const kidId = (await kid.get('/auth/me')).body.id;
  await owner.put(`/users/${kidId}/rooms`, { rooms: [{ roomId: state.livingRoom, access: 'VIEW' }] });
  const denied = await kid.post('/schedules', { kind: 'ONCE', inMinutes: 5, actions: [{ deviceId: state.bulb, on: true }] });
  assert.equal(denied.status, 403);

  // a timer two seconds from now turns the bulb on, through the normal acknowledged command path
  const runAt = new Date(Date.now() + 2000).toISOString();
  const timer = await owner.post('/schedules', { kind: 'ONCE', runAt, actions: [{ deviceId: state.bulb, on: true }] });
  assert.equal(timer.status, 201);
  assert.equal(timer.body.name, 'Bulb on');
  const done = await until('timer ran', async () => {
    const s = (await owner.get('/schedules')).body.find((x) => x.id === timer.body.id);
    return s?.lastRunAt ? s : null;
  }, 15000);
  assert.equal(done.enabled, false);
  assert.match(done.lastResult, /Done: Bulb on/);
  assert.equal((await owner.get(`/devices/${state.bulb}`)).body.state.on, true);
  const cmd = await prisma.command.findFirst({ where: { deviceId: state.bulb }, orderBy: { createdAt: 'desc' } });
  assert.equal(cmd.channel, 'automation');

  // daily schedules get a next run time and can be paused
  const daily = await owner.post('/schedules', { kind: 'DAILY', time: '19:00', days: [1, 2, 3, 4, 5], actions: [{ deviceId: state.bulb, on: true }] });
  assert.equal(daily.status, 201);
  assert.ok(new Date(daily.body.nextRunAt).getTime() > Date.now());
  assert.equal((await owner.patch(`/schedules/${daily.body.id}`, { enabled: false })).status, 204);
  assert.equal((await owner.del(`/schedules/${daily.body.id}`)).status, 204);
});

test('a water leak notifies the people of that room; health reports are kept for charts', async () => {
  const leak = await owner.post(`/nodes/${NODE_ID}/devices`, { name: 'Kitchen leak', type: 'contact', pin: 12, activeLow: true, roomId: state.livingRoom, settings: { kind: 'leak' } });
  assert.equal(leak.status, 201);
  await until('sensor reported', async () => (await owner.get(`/devices/${leak.body.id}`)).body.state?.active === false);
  fake.stdin.write(`trip ${leak.body.key}\n`);
  const notice = await until('leak notice', async () => (await owner.get('/notifications')).body.items.find((n) => n.kind === 'leak'));
  assert.equal(notice.severity, 'ALERT');
  assert.match(notice.title, /Water leak/);
  // the member can see the living room, so they are told too
  const kid = new Client();
  await kid.post('/auth/login', { email: 'kid@example.com', password: 'kidpass123' });
  const theirs = (await kid.get('/notifications')).body;
  assert.ok(theirs.unread >= 1 && theirs.items.some((n) => n.kind === 'leak'));
  assert.equal((await kid.post('/notifications/read')).status, 204);
  assert.equal((await kid.get('/notifications')).body.unread, 0);
  // people can switch a kind off
  const prefs = (await kid.put('/notifications/prefs', { leak: false })).body;
  assert.equal(prefs.find((p) => p.key === 'leak').enabled, false);
  assert.ok(!prefs.some((p) => p.key === 'boardOffline')); // admin-only kinds are not offered to members

  // the fake board sends a health report at start; it is stored
  const hist = await owner.get(`/nodes/${NODE_ID}/health-history?hours=1`);
  assert.equal(hist.status, 200);
  assert.ok(hist.body.length >= 1 && hist.body[0].vcc > 3000);
});

test('firmware: upload a build, send it to a board over Wi-Fi, the board verifies and runs it', async () => {
  const bad = new FormData();
  bad.append('file', new Blob([new Uint8Array([1, 2, 3])]), 'x.bin');
  bad.append('version', '9.9.9');
  const refused = await fetch(`${base}/firmware`, { method: 'POST', body: bad, headers: { Cookie: owner.cookieHeader } });
  assert.equal(refused.status, 400);

  const image = new Uint8Array(4096).fill(7);
  image[0] = 0xe9;
  const form = new FormData();
  form.append('file', new Blob([image]), 'home_node.ino.bin');
  form.append('version', '2.9.0-test');
  const up = await fetch(`${base}/firmware`, { method: 'POST', body: form, headers: { Cookie: owner.cookieHeader } });
  assert.equal(up.status, 201);
  const fw = await up.json();
  assert.equal(fw.size, 4096);

  const sent = await owner.post(`/nodes/${NODE_ID}/update`, { firmwareId: fw.id });
  assert.equal(sent.status, 201);
  await until('board runs the new firmware', async () => (await owner.get('/nodes')).body.find((n) => n.id === NODE_ID)?.firmware === '2.9.0-test', 10000);
  // links cannot be forged
  const forged = await fetch(`${base}/firmware/${fw.id}/download?node=${NODE_ID}&exp=${Date.now() + 60000}&sig=abc`);
  assert.equal(forged.status, 404);
  assert.equal((await member.get('/firmware')).status, 403);
});

test('a board that disappears goes offline and commands say so', async () => {
  fake.kill('SIGKILL');
  await until('offline via Last Will', async () => (await owner.get('/devices')).body.every((d) => !d.online), 12000);
  const res = await owner.post(`/devices/${state.bulb}/commands`, { on: false });
  assert.equal(res.status, 503);
  assert.match(res.body.message, /offline/);
  const n = await until('offline notice', async () => (await owner.get('/notifications')).body.items.find((x) => x.kind === 'boardOffline'));
  assert.match(n.title, /disconnected/);
});

test('the super admin dashboard sees everything; others are refused', async () => {
  const me = (await owner.get('/auth/me')).body;
  assert.equal(me.superAdmin, true); // SUPERADMIN_EMAILS empty: home owners are super admins
  const o = await owner.get('/admin/overview');
  assert.equal(o.status, 200);
  assert.equal(o.body.counts.homes, 1);
  assert.equal(o.body.services.database.ok, true);
  assert.ok(o.body.commands24h.total >= 3);
  assert.ok(o.body.boards.some((b) => b.id === NODE_ID));
  assert.ok(o.body.audit.length > 0);
  assert.equal((await owner.get('/admin/activity?hours=24')).status, 200);
  assert.equal((await member.get('/admin/overview')).status, 403);
});

test('the assistant reports clearly when it is not running', async () => {
  const res = await owner.post('/assistant/chat', { text: 'turn on the bulb' });
  assert.ok([503, 200].includes(res.status));
});
