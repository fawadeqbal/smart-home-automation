import { Body, Controller, Get, Headers, HttpCode, Param, Post, Put, Query } from '@nestjs/common';
import { z } from 'zod';
import { AuthUser } from '../auth/auth.types';
import { CurrentUser, Roles } from '../auth/decorators';
import { ZodPipe } from '../common/zod';
import { MonitoringService } from './monitoring.service';
import { PushService } from './push.service';

const subscription = z.object({ endpoint: z.string().url().max(1000), keys: z.object({ p256dh: z.string().max(200), auth: z.string().max(100) }) });

@Controller()
export class MonitoringController {
  constructor(private readonly monitoring: MonitoringService, private readonly push: PushService) {}

  @Get('push/key')
  pushKey() {
    return this.push.publicKey();
  }

  @Get('push/devices')
  pushDevices(@CurrentUser() user: AuthUser) {
    return this.push.count(user);
  }

  @Post('push/subscribe')
  @HttpCode(204)
  subscribe(@CurrentUser() user: AuthUser, @Body(new ZodPipe(subscription)) body: z.infer<typeof subscription>, @Headers('user-agent') ua?: string) {
    return this.push.subscribe(user, body, ua);
  }

  @Post('push/unsubscribe')
  @HttpCode(204)
  unsubscribe(@CurrentUser() user: AuthUser, @Body(new ZodPipe(z.object({ endpoint: z.string().max(1000) }))) body: { endpoint: string }) {
    return this.push.unsubscribe(user, body.endpoint);
  }

  @Get('notifications')
  list(@CurrentUser() user: AuthUser) {
    return this.monitoring.list(user);
  }

  @Post('notifications/read')
  @HttpCode(204)
  readAll(@CurrentUser() user: AuthUser) {
    return this.monitoring.markRead(user);
  }

  @Post('notifications/:id/read')
  @HttpCode(204)
  read(@CurrentUser() user: AuthUser, @Param('id') id: string) {
    return this.monitoring.markRead(user, id);
  }

  @Get('notifications/prefs')
  prefs(@CurrentUser() user: AuthUser) {
    return this.monitoring.prefs(user);
  }

  @Put('notifications/prefs')
  setPrefs(@CurrentUser() user: AuthUser, @Body(new ZodPipe(z.record(z.string(), z.boolean()))) body: Record<string, boolean>) {
    return this.monitoring.setPrefs(user, body);
  }

  @Roles('OWNER', 'ADMIN')
  @Get('nodes/:id/health-history')
  history(@CurrentUser() user: AuthUser, @Param('id') id: string, @Query('hours') hours?: string) {
    return this.monitoring.healthHistory(user.homeId, id, Math.min(24 * 14, Math.max(1, Number(hours) || 24)));
  }
}
