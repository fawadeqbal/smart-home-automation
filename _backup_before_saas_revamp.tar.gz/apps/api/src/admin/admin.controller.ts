import { Controller, ForbiddenException, Get, Inject, Injectable, Query } from '@nestjs/common';
import { CommandStatus, NodeStatus } from '@prisma/client';
import { AuthUser, isSuperAdmin } from '../auth/auth.types';
import { CurrentUser } from '../auth/decorators';
import { Settings, SETTINGS } from '../config';
import { NodesService } from '../hardware/nodes.service';
import { MqttService } from '../mqtt/mqtt.service';
import { PrismaService } from '../prisma/prisma.service';

const STARTED = Date.now();

async function timed<T>(fn: () => Promise<T>): Promise<{ ok: boolean; ms: number; value?: T; error?: string }> {
  const t = Date.now();
  try {
    const value = await fn();
    return { ok: true, ms: Date.now() - t, value };
  } catch (err) {
    return { ok: false, ms: Date.now() - t, error: (err as Error).message };
  }
}

/** The platform operator's view: every home, board and service. Read-only. */
@Injectable()
export class AdminService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly mqtt: MqttService,
    private readonly nodes: NodesService,
    @Inject(SETTINGS) private readonly settings: Settings,
  ) {}

  assert(user: AuthUser) {
    if (!isSuperAdmin(this.settings.superAdminEmails, user)) throw new ForbiddenException('Super admins only.');
  }

  async overview() {
    const day = new Date(Date.now() - 86400000);
    const [db, assistant] = await Promise.all([
      timed(async () => {
        const rows = await this.prisma.$queryRaw<{ size: string }[]>`SELECT pg_size_pretty(pg_database_size(current_database())) AS size`;
        return rows[0]?.size;
      }),
      timed(async () => {
        const res = await fetch(`${this.settings.assistantUrl}/health`, { signal: AbortSignal.timeout(3000) });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        return (await res.json()) as { llm?: string };
      }),
    ]);

    const [homes, users, nodes, devices, commands24, failed, schedules, scenes, audit, nextSchedule] = await Promise.all([
      this.prisma.home.findMany({ include: { _count: { select: { users: true, nodes: true, rooms: true } }, users: { where: { role: 'OWNER' }, select: { name: true, email: true } } } }),
      this.prisma.user.groupBy({ by: ['role'], _count: true }),
      this.prisma.node.findMany({ include: { home: { select: { name: true } }, _count: { select: { devices: true } } }, orderBy: [{ online: 'desc' }, { lastSeenAt: 'desc' }] }),
      this.prisma.device.groupBy({ by: ['type'], _count: true }),
      this.prisma.command.groupBy({ by: ['status', 'channel'], where: { createdAt: { gte: day } }, _count: true }),
      this.prisma.command.findMany({
        where: { status: { in: [CommandStatus.FAILED, CommandStatus.TIMEOUT] } },
        orderBy: { createdAt: 'desc' }, take: 12,
        include: { device: { select: { name: true, node: { select: { name: true, home: { select: { name: true } } } } } } },
      }),
      this.prisma.schedule.count({ where: { enabled: true } }),
      this.prisma.scene.count(),
      this.prisma.auditLog.findMany({ orderBy: { at: 'desc' }, take: 25 }),
      this.prisma.schedule.findFirst({ where: { enabled: true }, orderBy: { nextRunAt: 'asc' }, select: { name: true, nextRunAt: true } }),
    ]);
    const names = new Map((await this.prisma.user.findMany({ select: { id: true, name: true } })).map((u) => [u.id, u.name]));
    const homeNames = new Map(homes.map((h) => [h.id, h.name]));

    const cmd = { total: 0, acked: 0, failed: 0, timeout: 0, pending: 0, byChannel: {} as Record<string, number> };
    for (const row of commands24) {
      cmd.total += row._count;
      if (row.status === 'ACKED') cmd.acked += row._count;
      if (row.status === 'FAILED') cmd.failed += row._count;
      if (row.status === 'TIMEOUT') cmd.timeout += row._count;
      if (row.status === 'PENDING') cmd.pending += row._count;
      cmd.byChannel[row.channel] = (cmd.byChannel[row.channel] ?? 0) + row._count;
    }
    const adopted = nodes.filter((n) => n.status === NodeStatus.ADOPTED);
    const mem = process.memoryUsage();

    return {
      generatedAt: new Date().toISOString(),
      services: {
        api: { ok: true, uptimeSec: Math.round((Date.now() - STARTED) / 1000), node: process.version, memoryMb: Math.round(mem.rss / 1048576), heapMb: Math.round(mem.heapUsed / 1048576) },
        database: { ok: db.ok, ms: db.ms, size: db.value ?? null, error: db.error ?? null },
        broker: { ok: this.mqtt.connected, url: this.settings.mqttUrl.replace(/\/\/.*@/, '//') },
        assistant: { ok: assistant.ok, ms: assistant.ms, llm: assistant.value?.llm ?? null, error: assistant.error ?? null },
        scheduler: { ok: true, active: schedules, scenes, next: nextSchedule },
      },
      counts: {
        homes: homes.length,
        users: Object.fromEntries(users.map((u) => [u.role, u._count])),
        boards: { total: adopted.length, online: adopted.filter((n) => n.online).length, pending: nodes.length - adopted.length },
        devices: Object.fromEntries(devices.map((d) => [d.type, d._count])),
      },
      commands24h: cmd,
      failures: failed.map((c) => ({
        at: c.createdAt, status: c.status, error: c.error, channel: c.channel, device: c.device.name,
        board: c.device.node.name, home: c.device.node.home.name, by: c.userId ? names.get(c.userId) ?? null : null,
      })),
      homes: homes.map((h) => ({
        id: h.id, name: h.name, timezone: h.timezone, owner: h.users[0]?.name ?? '—', ownerEmail: h.users[0]?.email ?? '',
        users: h._count.users, boards: h._count.nodes, rooms: h._count.rooms,
      })),
      boards: nodes.map((n) => {
        const h = this.nodes.healthOf(n.id) as { vcc?: number; heap?: number; uptime?: number } | null;
        return {
          id: n.id, name: n.name, home: n.home.name, status: n.status, online: n.online, lastSeenAt: n.lastSeenAt,
          firmware: n.firmware, rssi: n.rssi, devices: n._count.devices, configOk: n.appliedRev === n.configRev && !n.configError,
          vcc: h?.vcc ?? null, heap: h?.heap ?? null, uptime: h?.uptime ?? null,
        };
      }),
      audit: audit.map((a) => ({
        at: a.at, action: a.action, home: homeNames.get(a.homeId) ?? a.homeId, by: a.userId ? names.get(a.userId) ?? 'deleted user' : 'system',
        details: a.details,
      })),
    };
  }

  /** Command volume per hour for the last `hours` (for the activity chart). */
  async activity(hours: number) {
    const since = new Date(Date.now() - hours * 3600000);
    const rows = await this.prisma.$queryRaw<{ hour: Date; ok: bigint; bad: bigint }[]>`
      SELECT date_trunc('hour', "createdAt") AS hour,
             COUNT(*) FILTER (WHERE status = 'ACKED') AS ok,
             COUNT(*) FILTER (WHERE status IN ('FAILED', 'TIMEOUT')) AS bad
      FROM "Command" WHERE "createdAt" >= ${since} GROUP BY 1 ORDER BY 1`;
    return rows.map((r) => ({ hour: r.hour, ok: Number(r.ok), bad: Number(r.bad) }));
  }
}

@Controller('admin')
export class AdminController {
  constructor(private readonly admin: AdminService) {}

  @Get('overview')
  overview(@CurrentUser() user: AuthUser) {
    this.admin.assert(user);
    return this.admin.overview();
  }

  @Get('activity')
  activity(@CurrentUser() user: AuthUser, @Query('hours') hours?: string) {
    this.admin.assert(user);
    return this.admin.activity(Math.min(168, Math.max(1, Number(hours) || 24)));
  }
}
