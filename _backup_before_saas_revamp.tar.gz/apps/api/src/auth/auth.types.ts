import { Role } from '@prisma/client';

/** The signed-in person, attached to every authenticated request. */
export interface AuthUser {
  id: string;
  homeId: string;
  role: Role;
  name: string;
  email: string;
  /** "web" for a browser session, "voice" when the assistant acts on their behalf. */
  channel: 'web' | 'voice' | 'automation';
}

export const ACCESS_COOKIE = 'access';
export const REFRESH_COOKIE = 'refresh';
export const ACCESS_TTL_SEC = 15 * 60;
export const REFRESH_TTL_SEC = 30 * 24 * 3600;
export const ON_BEHALF_TTL_SEC = 120;

export interface AccessClaims {
  sub: string;
  typ: 'access' | 'obo';
}

export const isAdmin = (role: Role) => role === Role.OWNER || role === Role.ADMIN;

/** Super admins run the whole platform. Listed in SUPERADMIN_EMAILS; when that is empty, home owners are. */
export const isSuperAdmin = (emails: string[], user: { email: string; role: Role }) =>
  emails.length ? emails.includes(user.email.toLowerCase()) : user.role === Role.OWNER;
