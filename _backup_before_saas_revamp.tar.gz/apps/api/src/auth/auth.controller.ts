import { Body, Controller, Get, HttpCode, Post, Req, Res } from '@nestjs/common';
import type { Request, Response } from 'express';
import { z } from 'zod';
import { ZodPipe } from '../common/zod';
import { MqttService } from '../mqtt/mqtt.service';
import { UsersService } from '../users/users.service';
import { AuthService } from './auth.service';
import { AuthUser, REFRESH_COOKIE } from './auth.types';
import { CurrentUser, Public } from './decorators';

export const passwordSchema = z.string().min(8, 'Password must be at least 8 characters').max(200);
const emailSchema = z.string().trim().toLowerCase().email('Enter a valid email address');

const setupSchema = z.object({
  homeName: z.string().trim().min(1).max(80),
  name: z.string().trim().min(1).max(80),
  email: emailSchema,
  password: passwordSchema,
});
const loginSchema = z.object({ email: emailSchema, password: z.string().min(1) });

@Controller('auth')
export class AuthController {
  constructor(
    private readonly auth: AuthService,
    private readonly users: UsersService,
    private readonly mqtt: MqttService,
  ) {}

  @Public()
  @Get('status')
  async status() {
    return { setupNeeded: await this.auth.setupNeeded() };
  }

  /** First run only: creates the home and its owner. */
  @Public()
  @Post('setup')
  async setup(@Body(new ZodPipe(setupSchema)) body: z.infer<typeof setupSchema>, @Req() req: Request,
              @Res({ passthrough: true }) res: Response) {
    const user = await this.auth.setup(body);
    await this.auth.startSession(user, res, req.headers['user-agent']);
    await this.mqtt.resubscribe(); // pick up boards that announced before the home existed
    return this.users.me(user.id);
  }

  @Public()
  @Post('login')
  @HttpCode(200)
  async login(@Body(new ZodPipe(loginSchema)) body: z.infer<typeof loginSchema>, @Req() req: Request,
              @Res({ passthrough: true }) res: Response) {
    const user = await this.auth.login(body.email, body.password);
    await this.auth.startSession(user, res, req.headers['user-agent']);
    return this.users.me(user.id);
  }

  @Public()
  @Post('refresh')
  @HttpCode(200)
  async refresh(@Req() req: Request, @Res({ passthrough: true }) res: Response) {
    const user = await this.auth.refresh(req.cookies?.[REFRESH_COOKIE], res);
    return this.users.me(user.id);
  }

  @Public()
  @Post('logout')
  @HttpCode(204)
  async logout(@Req() req: Request, @Res({ passthrough: true }) res: Response) {
    await this.auth.logout(req.cookies?.[REFRESH_COOKIE], res);
  }

  @Get('me')
  me(@CurrentUser() user: AuthUser) {
    return this.users.me(user.id);
  }
}
