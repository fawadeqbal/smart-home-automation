import { CanActivate, ExecutionContext, ForbiddenException, Injectable } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { Role } from '@prisma/client';
import type { Request } from 'express';
import { AuthService } from './auth.service';
import { ACCESS_COOKIE } from './auth.types';
import { PUBLIC_KEY, ROLES_KEY } from './decorators';

/**
 * Global guard: every route needs a signed-in person unless marked @Public().
 * Browsers send the "access" cookie; the voice assistant sends "Authorization: Bearer <on-behalf token>".
 */
@Injectable()
export class AuthGuard implements CanActivate {
  constructor(private readonly reflector: Reflector, private readonly auth: AuthService) {}

  async canActivate(ctx: ExecutionContext): Promise<boolean> {
    const targets = [ctx.getHandler(), ctx.getClass()];
    if (this.reflector.getAllAndOverride<boolean>(PUBLIC_KEY, targets)) return true;

    const req = ctx.switchToHttp().getRequest<Request & { user?: unknown }>();
    const bearer = req.headers.authorization?.startsWith('Bearer ') ? req.headers.authorization.slice(7) : undefined;
    const user = bearer
      ? await this.auth.authenticate(bearer, ['obo'])
      : await this.auth.authenticate(req.cookies?.[ACCESS_COOKIE] ?? '', ['access']);
    req.user = user;

    const roles = this.reflector.getAllAndOverride<Role[] | undefined>(ROLES_KEY, targets);
    if (roles && !roles.includes(user.role)) throw new ForbiddenException('You do not have permission for this.');
    return true;
  }
}
