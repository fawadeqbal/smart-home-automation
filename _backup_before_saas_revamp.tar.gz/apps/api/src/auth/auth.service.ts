import {
  ConflictException, ForbiddenException, HttpException, HttpStatus, Inject, Injectable, UnauthorizedException,
} from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { hash, verify } from '@node-rs/argon2';
import { Role, User } from '@prisma/client';
import { createHash, randomBytes } from 'node:crypto';
import type { CookieOptions, Response } from 'express';
import { SETTINGS, Settings } from '../config';
import { PrismaService } from '../prisma/prisma.service';
import {
  ACCESS_COOKIE, ACCESS_TTL_SEC, AccessClaims, AuthUser, ON_BEHALF_TTL_SEC, REFRESH_COOKIE, REFRESH_TTL_SEC,
} from './auth.types';

const MAX_FAILED_LOGINS = 5;
const LOCK_MS = 15 * 60 * 1000;

export const sha256 = (value: string) => createHash('sha256').update(value).digest('hex');
export const randomToken = () => randomBytes(32).toString('base64url');

@Injectable()
export class AuthService {
  /** email -> failed attempts. In memory: fine for one API instance. */
  private readonly failures = new Map<string, { count: number; lockedUntil: number }>();

  constructor(
    private readonly prisma: PrismaService,
    private readonly jwt: JwtService,
    @Inject(SETTINGS) private readonly settings: Settings,
  ) {}

  // ---------------------------------------------------------------- passwords
  hashPassword(password: string) {
    return hash(password); // argon2id with safe defaults
  }

  // ---------------------------------------------------------------- first run
  async setupNeeded(): Promise<boolean> {
    return (await this.prisma.user.count()) === 0;
  }

  async setup(input: { homeName: string; name: string; email: string; password: string }): Promise<User> {
    if (!(await this.setupNeeded())) throw new ConflictException('This home is already set up. Sign in instead.');
    const passwordHash = await this.hashPassword(input.password);
    return this.prisma.$transaction(async (tx) => {
      const home = await tx.home.create({ data: { name: input.homeName } });
      await tx.room.create({ data: { homeId: home.id, name: 'Living room' } });
      return tx.user.create({
        data: { homeId: home.id, name: input.name, email: input.email.toLowerCase(), passwordHash, role: Role.OWNER },
      });
    });
  }

  // ---------------------------------------------------------------- sign in
  async login(email: string, password: string): Promise<User> {
    const key = email.toLowerCase();
    const state = this.failures.get(key);
    if (state && state.lockedUntil > Date.now()) {
      throw new HttpException('Too many failed attempts. Try again in 15 minutes.', HttpStatus.TOO_MANY_REQUESTS);
    }
    const user = await this.prisma.user.findUnique({ where: { email: key } });
    const ok = user ? await verify(user.passwordHash, password) : false;
    if (!user || !ok) {
      const count = (state?.count ?? 0) + 1;
      this.failures.set(key, { count, lockedUntil: count >= MAX_FAILED_LOGINS ? Date.now() + LOCK_MS : 0 });
      throw new UnauthorizedException('Wrong email or password.');
    }
    if (user.disabled) throw new ForbiddenException('This account is disabled. Ask the home owner.');
    this.failures.delete(key);
    return user;
  }

  /** Creates a session (refresh token) and sets both cookies. */
  async startSession(user: User, res: Response, userAgent?: string) {
    const refresh = randomToken();
    await this.prisma.session.create({
      data: {
        userId: user.id,
        refreshHash: sha256(refresh),
        userAgent: userAgent?.slice(0, 200),
        expiresAt: new Date(Date.now() + REFRESH_TTL_SEC * 1000),
      },
    });
    this.setCookies(res, user.id, refresh);
  }

  /** Swaps a valid refresh token for a new pair (rotation: each refresh token works once). */
  async refresh(refreshToken: string | undefined, res: Response) {
    if (!refreshToken) throw new UnauthorizedException('Not signed in.');
    const session = await this.prisma.session.findUnique({
      where: { refreshHash: sha256(refreshToken) },
      include: { user: true },
    });
    if (!session || session.revokedAt || session.expiresAt < new Date() || session.user.disabled) {
      this.clearCookies(res);
      throw new UnauthorizedException('Session expired. Sign in again.');
    }
    const next = randomToken();
    await this.prisma.session.update({
      where: { id: session.id },
      data: { refreshHash: sha256(next), expiresAt: new Date(Date.now() + REFRESH_TTL_SEC * 1000) },
    });
    this.setCookies(res, session.userId, next);
    return session.user;
  }

  async logout(refreshToken: string | undefined, res: Response) {
    if (refreshToken) {
      await this.prisma.session.updateMany({
        where: { refreshHash: sha256(refreshToken), revokedAt: null },
        data: { revokedAt: new Date() },
      });
    }
    this.clearCookies(res);
  }

  // ---------------------------------------------------------------- tokens
  /** Verifies a token and loads the person. typ "obo" = the assistant acting for them. */
  async authenticate(token: string, allowed: AccessClaims['typ'][]): Promise<AuthUser> {
    let claims: AccessClaims;
    try {
      claims = await this.jwt.verifyAsync<AccessClaims>(token);
    } catch {
      throw new UnauthorizedException('Not signed in or session expired.');
    }
    if (!allowed.includes(claims.typ)) throw new UnauthorizedException('Wrong kind of token.');
    const user = await this.prisma.user.findUnique({ where: { id: claims.sub } });
    if (!user || user.disabled) throw new UnauthorizedException('Account not available.');
    return {
      id: user.id, homeId: user.homeId, role: user.role, name: user.name, email: user.email,
      channel: claims.typ === 'obo' ? 'voice' : 'web',
    };
  }

  /** Short-lived token the voice assistant uses to act with this person's rights. */
  onBehalfToken(user: AuthUser): Promise<string> {
    return this.jwt.signAsync({ sub: user.id, typ: 'obo' } satisfies AccessClaims, { expiresIn: ON_BEHALF_TTL_SEC });
  }

  private cookieOptions(maxAgeSec: number, path = '/'): CookieOptions {
    return { httpOnly: true, secure: this.settings.cookieSecure, sameSite: 'lax', path, maxAge: maxAgeSec * 1000 };
  }

  private setCookies(res: Response, userId: string, refresh: string) {
    const access = this.jwt.sign({ sub: userId, typ: 'access' } satisfies AccessClaims, { expiresIn: ACCESS_TTL_SEC });
    res.cookie(ACCESS_COOKIE, access, this.cookieOptions(ACCESS_TTL_SEC));
    res.cookie(REFRESH_COOKIE, refresh, this.cookieOptions(REFRESH_TTL_SEC, '/api/auth'));
  }

  private clearCookies(res: Response) {
    res.clearCookie(ACCESS_COOKIE, { path: '/' });
    res.clearCookie(REFRESH_COOKIE, { path: '/api/auth' });
  }
}
