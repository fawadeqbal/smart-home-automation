import { Global, Injectable, Logger, Module } from '@nestjs/common';
import { Prisma } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';

/** Records who changed what: users, rights, rooms, boards and pins. */
@Injectable()
export class AuditService {
  private readonly log = new Logger('Audit');

  constructor(private readonly prisma: PrismaService) {}

  async record(homeId: string, userId: string | null, action: string, target: string, details: object = {}) {
    try {
      await this.prisma.auditLog.create({
        data: { homeId, userId, action, target, details: details as Prisma.InputJsonValue },
      });
    } catch (err) {
      this.log.warn(`Could not write audit entry ${action}: ${err}`); // never break the request for it
    }
  }
}

@Global()
@Module({ providers: [AuditService], exports: [AuditService] })
export class AuditModule {}
