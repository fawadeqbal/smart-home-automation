import {
  BadRequestException, ConflictException, ForbiddenException, GoneException, Inject, Injectable, NotFoundException,
} from '@nestjs/common';
import { Access, Role } from '@prisma/client';
import { AuthService, randomToken, sha256 } from '../auth/auth.service';
import { AuthUser, isAdmin, isSuperAdmin } from '../auth/auth.types';
import { Settings, SETTINGS } from '../config';
import { AuditService } from '../common/audit.service';
import { PrismaService } from '../prisma/prisma.service';
import { RealtimeService } from '../realtime/realtime.service';

const INVITE_TTL_MS = 7 * 24 * 3600 * 1000;

@Injectable()
export class UsersService {
  constructor(
    @Inject(SETTINGS) private readonly settings: Settings,
    private readonly prisma: PrismaService,
    private readonly auth: AuthService,
    private readonly audit: AuditService,
    private readonly realtime: RealtimeService,
  ) {}

  async me(userId: string) {
    const user = await this.prisma.user.findUniqueOrThrow({
      where: { id: userId },
      include: { home: true, rooms: true },
    });
    return {
      id: user.id, name: user.name, email: user.email, role: user.role,
      superAdmin: isSuperAdmin(this.settings.superAdminEmails, user),
      home: { id: user.home.id, name: user.home.name },
      rooms: user.rooms.map((r) => ({ roomId: r.roomId, access: r.access })),
    };
  }

  async list(actor: AuthUser) {
    const users = await this.prisma.user.findMany({
      where: { homeId: actor.homeId },
      include: { rooms: true },
      orderBy: { createdAt: 'asc' },
    });
    return users.map((u) => ({
      id: u.id, name: u.name, email: u.email, role: u.role, disabled: u.disabled,
      rooms: u.rooms.map((r) => ({ roomId: r.roomId, access: r.access })),
    }));
  }

  /** Owners may change anyone but themselves; admins may manage members and guests only. */
  private async target(actor: AuthUser, userId: string) {
    const user = await this.prisma.user.findFirst({ where: { id: userId, homeId: actor.homeId } });
    if (!user) throw new NotFoundException('No such person in this home.');
    if (user.id === actor.id) throw new BadRequestException('You cannot change your own account here.');
    if (actor.role !== Role.OWNER && isAdmin(user.role)) {
      throw new ForbiddenException('Only the owner can change an owner or admin.');
    }
    return user;
  }

  async update(actor: AuthUser, userId: string, input: { role?: Role; disabled?: boolean; name?: string }) {
    const user = await this.target(actor, userId);
    if (input.role === Role.OWNER) throw new BadRequestException('A home has exactly one owner.');
    if (input.role === Role.ADMIN && actor.role !== Role.OWNER) {
      throw new ForbiddenException('Only the owner can make someone an admin.');
    }
    const updated = await this.prisma.user.update({ where: { id: user.id }, data: input });
    if (input.disabled) {
      await this.prisma.session.updateMany({ where: { userId: user.id, revokedAt: null }, data: { revokedAt: new Date() } });
    }
    await this.audit.record(actor.homeId, actor.id, 'user.update', user.id, input);
    this.realtime.accessChanged(user.id);
    return { id: updated.id, role: updated.role, disabled: updated.disabled, name: updated.name };
  }

  async setRooms(actor: AuthUser, userId: string, rooms: { roomId: string; access: Access }[]) {
    const user = await this.target(actor, userId);
    const valid = await this.prisma.room.findMany({ where: { homeId: actor.homeId, id: { in: rooms.map((r) => r.roomId) } } });
    if (valid.length !== new Set(rooms.map((r) => r.roomId)).size) throw new BadRequestException('Unknown room.');
    await this.prisma.$transaction([
      this.prisma.roomAccess.deleteMany({ where: { userId: user.id } }),
      this.prisma.roomAccess.createMany({ data: rooms.map((r) => ({ userId: user.id, roomId: r.roomId, access: r.access })) }),
    ]);
    await this.audit.record(actor.homeId, actor.id, 'user.rooms', user.id, { rooms });
    this.realtime.accessChanged(user.id);
    return { ok: true };
  }

  async remove(actor: AuthUser, userId: string) {
    const user = await this.target(actor, userId);
    await this.prisma.user.delete({ where: { id: user.id } });
    await this.audit.record(actor.homeId, actor.id, 'user.remove', user.id, { email: user.email });
    this.realtime.accessChanged(user.id);
  }

  // ---------------------------------------------------------------- invites
  async invite(actor: AuthUser, email: string, role: Role) {
    if (role === Role.OWNER) throw new BadRequestException('A home has exactly one owner.');
    if (role === Role.ADMIN && actor.role !== Role.OWNER) throw new ForbiddenException('Only the owner can invite an admin.');
    if (await this.prisma.user.findUnique({ where: { email } })) throw new ConflictException('This email already has an account.');
    const token = randomToken();
    await this.prisma.invite.create({
      data: {
        homeId: actor.homeId, email, role, tokenHash: sha256(token), createdBy: actor.id,
        expiresAt: new Date(Date.now() + INVITE_TTL_MS),
      },
    });
    await this.audit.record(actor.homeId, actor.id, 'invite.create', email, { role });
    return { token, path: `/invite/${token}`, expiresInDays: 7 };
  }

  async listInvites(actor: AuthUser) {
    return this.prisma.invite.findMany({
      where: { homeId: actor.homeId, usedAt: null, expiresAt: { gt: new Date() } },
      select: { id: true, email: true, role: true, expiresAt: true },
      orderBy: { createdAt: 'desc' },
    });
  }

  async revokeInvite(actor: AuthUser, id: string) {
    await this.prisma.invite.deleteMany({ where: { id, homeId: actor.homeId } });
  }

  private async openInvite(token: string) {
    const invite = await this.prisma.invite.findUnique({ where: { tokenHash: sha256(token) }, include: { home: true } });
    if (!invite || invite.usedAt || invite.expiresAt < new Date()) {
      throw new GoneException('This invite link is no longer valid. Ask for a new one.');
    }
    return invite;
  }

  async describeInvite(token: string) {
    const invite = await this.openInvite(token);
    return { email: invite.email, role: invite.role, homeName: invite.home.name };
  }

  async acceptInvite(token: string, name: string, password: string) {
    const invite = await this.openInvite(token);
    const passwordHash = await this.auth.hashPassword(password);
    const user = await this.prisma.$transaction(async (tx) => {
      await tx.invite.update({ where: { id: invite.id }, data: { usedAt: new Date() } });
      return tx.user.create({
        data: { homeId: invite.homeId, email: invite.email, name, passwordHash, role: invite.role },
      });
    });
    await this.audit.record(invite.homeId, user.id, 'invite.accept', user.id, { email: user.email });
    return user;
  }
}
