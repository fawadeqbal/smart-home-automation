'use client';
import Link from 'next/link';
import { useState } from 'react';
import { errorText, post } from '@/lib/api';
import { timeAgo } from '@/lib/hooks';
import type { Device } from '@/lib/types';
import { Icon } from './Icon';
import { analogLabel, contactText, deviceIcon } from '@/lib/format';
import { Spinner } from './Loader';

function fmt(value: unknown): string {
  return typeof value === 'number' ? (Number.isInteger(value) ? String(value) : value.toFixed(1)) : '–';
}

export function DeviceCard({ device, onChange }: { device: Device; onChange: (d: Device) => void }) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const on = device.state?.on === true;
  const canControl = device.access !== 'VIEW';

  async function toggle() {
    setBusy(true);
    setError(null);
    try {
      onChange(await post<Device>(`/devices/${device.id}/commands`, { on: !on }));
    } catch (err) {
      setError(errorText(err));
    } finally {
      setBusy(false);
    }
  }

  const status = !device.online ? 'Offline' : device.controllable ? (on ? 'On' : 'Off') : `Updated ${timeAgo(device.updatedAt)}`;
  const classes = ['device', on && device.online ? 'is-on' : '', !device.online ? 'is-offline' : '', busy ? 'is-busy' : ''].join(' ');
  const room = device.roomName ?? 'No room';
  const foot = (
    <Link className="device-foot" href={`/devices/${device.id}`}>View history<Icon name="chevron-right" size={14} /></Link>
  );

  if (!device.controllable) {
    return (
      <div className={classes}>
        <div className="device-body">
          <div className="device-top">
            <span className="device-icon"><Icon name={deviceIcon(device.type, device.settings)} size={19} /></span>
          </div>
          {device.type === 'contact' ? (
            <div className="reading"><span className={`reading-value ${device.state?.active ? 'text-alert' : ''}`}>{contactText(device.settings, device.state?.active)}</span></div>
          ) : device.type === 'analog' ? (
            <div className="reading">
              <span className="reading-value">{fmt(device.state?.level)}%</span>
              <span className="reading-extra">{analogLabel(device.settings)}</span>
            </div>
          ) : (
          <div className="reading">
            {device.stateFields.map((f, i) => (
              <span key={f.key} className={i === 0 ? 'reading-value' : 'reading-extra'}>
                {fmt(device.state?.[f.key])}{f.unit}{i > 0 ? ` ${f.label.toLowerCase()}` : ''}
              </span>
            ))}
          </div>
          )}
          <div className="device-text"><b className="device-name">{device.name}</b><span className="device-meta">{room} · {status}</span></div>
        </div>
        {foot}
      </div>
    );
  }

  return (
    <div className={classes}>
      <button
        className="device-body"
        onClick={toggle}
        disabled={busy || !device.online || !canControl}
        aria-pressed={on}
        title={!canControl ? 'You can view this device but not switch it' : undefined}
      >
        <div className="device-top">
          <span className="device-icon"><Icon name="lightbulb" size={19} /></span>
          {busy ? <Spinner size={20} /> : <span className="switch" aria-hidden />}
        </div>
        <div className="device-text">
          <b className="device-name">{device.name}</b>
          <span className="device-meta">
            {room} · {busy ? 'Switching…' : status}{device.source === 'button' && device.online ? ' · wall switch' : ''}
          </span>
        </div>
      </button>
      {error && <div className="device-error">{error}</div>}
      {foot}
    </div>
  );
}
