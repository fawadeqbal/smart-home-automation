'use client';
import Link from 'next/link';
import { FormEvent, useState } from 'react';
import { BoardDiagram, pinStats } from '@/components/BoardDiagram';
import { boardCondition, ConditionLight, HealthPanel } from '@/components/BoardHealth';
import { FirmwarePanel } from '@/components/FirmwarePanel';
import { HealthCharts } from '@/components/HealthCharts';
import { DeviceForm, DeviceFormValues, freePins } from '@/components/DeviceForm';
import { LogPanel } from '@/components/LogPanel';
import { NetworkPanel } from '@/components/NetworkPanel';
import { del, errorText, patch, post } from '@/lib/api';
import { timeAgo, useNow } from '@/lib/hooks';
import { analogLabel, contactText } from '@/lib/format';
import type { BoardNode, Catalog, NodeDevice, Room } from '@/lib/types';
import { PageHelp, Tip } from '@/components/Help';

const TABS: { id: BoardTab; label: string }[] = [
  { id: 'overview', label: 'Overview' },
  { id: 'devices', label: 'Devices' },
  { id: 'pins', label: 'Pins & wiring' },
  { id: 'network', label: 'Network' },
  { id: 'logs', label: 'Activity log' },
];

const HELP: Record<BoardTab, { title: string; body: React.ReactNode }> = {
  overview: {
    title: 'Is this board OK?',
    body: (
      <ul>
        <li>The big light is the board’s condition. <b className="text-ok">Green</b> = all good. <b className="text-warn">Amber</b> = works, but look at the message. <b className="text-bad">Red</b> = it is offline or refused its settings.</li>
        <li><b>Supply voltage</b> should be 3.0–3.6 V. Lower means a weak USB cable or power supply.</li>
        <li><b>Wi‑Fi signal</b>: “Weak” boards drop out. Move it or the router closer.</li>
        <li><b>Restart</b> reboots the board (about 5 seconds). <b>Remove</b> takes it out of your home.</li>
      </ul>
    ),
  },
  devices: {
    title: 'What is connected to this board',
    body: (
      <ul>
        <li><b>Add device</b>: a relay for a light/fan/socket, a temperature sensor, a door/motion sensor…</li>
        <li><b>Add wall button</b>: a push‑button wired between a pin and G (ground) that toggles a light — it works even without Wi‑Fi.</li>
        <li>Only safe, free pins are offered. Changes reach the board in about a second (“Settings saved”).</li>
        <li><b>Other names for voice</b> let the assistant understand “batti” or “lamp” for the same light.</li>
      </ul>
    ),
  },
  pins: {
    title: 'Which wire goes where',
    body: (
      <ul>
        <li>The drawing matches the printing on your board. Hover a pin to see what it can do.</li>
        <li><b className="text-ok">Green ring</b> = free. <b>Blue</b> = in use (its device is named next to it). <b>Yellow</b> = power: 3V = 3.3 V, G = ground, VU/VIN = 5 V. <b>Grey</b> = reserved, don’t use.</li>
        <li>Relays: signal to the pin, VCC to VIN/VU, GND to G. Sensors: power from 3V.</li>
      </ul>
    ),
  },
  network: {
    title: 'Wi‑Fi of this board',
    body: (
      <ul>
        <li><b>Connected to</b> shows its Wi‑Fi, signal and addresses.</li>
        <li><b>Scan now</b> lists the networks the board can hear. Pick one and enter its password to move the board — handy for a new router or a closer extender.</li>
        <li>It is safe: if the new network doesn’t work within 30 seconds, the board goes back to the old one.</li>
        <li>Only 2.4 GHz Wi‑Fi works; 5 GHz networks never appear.</li>
      </ul>
    ),
  },
  logs: {
    title: 'What the board is doing right now',
    body: (
      <ul>
        <li>Every message the board prints arrives here live — no USB cable needed.</li>
        <li><b>board</b> lines come from the board; <b>server</b> lines are what this app did (sent settings, switched a light…).</li>
        <li>Choose <b>All</b> in the menu to also see every sensor reading.</li>
      </ul>
    ),
  },
};

/** Online / disconnected strip with the last activity time. */
export function BoardStatus({ node }: { node: BoardNode }) {
  useNow(10_000);
  return node.online ? (
    <div className="board-status ok">
      <span className="live-dot" />
      <span><b>Online</b> · last activity {timeAgo(node.lastSeenAt)}</span>
    </div>
  ) : (
    <div className="board-status bad" role="status">
      <span className="live-dot off" />
      <span>
        <b>Disconnected</b>{node.lastSeenAt ? ` since ${new Date(node.lastSeenAt).toLocaleString([], { hour: '2-digit', minute: '2-digit', day: 'numeric', month: 'short' })} (${timeAgo(node.lastSeenAt)})` : ' — never connected'}.
        {' '}Its devices can’t be switched from the app until it’s back. Check its power and Wi‑Fi; wall buttons still work on the board.
      </span>
    </div>
  );
}

function BoardOverview({ node, catalog, onTab, reload }: { node: BoardNode; catalog: Catalog; onTab: (t: BoardTab) => void; reload: () => void }) {
  const [boardError, setBoardError] = useState<string | null>(null);
  const s = pinStats(node, catalog);
  const signal = node.rssi === null ? '—' : node.rssi > -60 ? 'Strong' : node.rssi > -72 ? 'Good' : node.rssi > -82 ? 'Weak' : 'Very weak';
  const tiles = [
    { label: 'Devices', value: node.devices.length, go: 'devices' as BoardTab },
    { label: 'Wall buttons', value: node.inputs.length, go: 'devices' as BoardTab },
    { label: 'Pins in use', value: s.used, go: 'pins' as BoardTab },
    { label: 'Pins still free', value: s.free, go: 'pins' as BoardTab },
  ];
  return (
    <div className="stack">
      <ConditionLight node={node} />
      <h3 className="sub-head">Board health</h3>
      <HealthPanel node={node} />
      <HealthCharts nodeId={node.id} />
      <FirmwarePanel node={node} />
      <h3 className="sub-head">Usage</h3>
      <div className="stats">
        {tiles.map((t) => (
          <button key={t.label} className="stat stat-btn" onClick={() => onTab(t.go)}>
            <span className="stat-label">{t.label}</span>
            <span className="stat-value">{t.value}</span>
          </button>
        ))}
      </div>
      <div className="card card-pad">
        <dl className="facts">
          <dt>Board model <Tip>Pick the one that looks like yours, so the pin drawing matches the board in your hand. The pins work the same.</Tip></dt>
          <dd>
            <select className="inline-select" value={node.board} aria-label="Board model" onChange={(e) => {
              setBoardError(null);
              patch(`/nodes/${node.id}`, { board: e.target.value }).then(reload).catch((err) => setBoardError(errorText(err)));
            }}>
              {catalog.boards.map((b) => <option key={b.type} value={b.type}>{b.name}</option>)}
            </select>
            {boardError && <div className="alert" style={{ marginTop: 6 }}>{boardError}</div>}
          </dd>
          <dt>Board ID <Tip>Printed by the board at start-up and part of its Wi‑Fi name (HomeNode‑…). It never changes.</Tip></dt><dd className="mono">{node.id}</dd>
          <dt>IP address</dt><dd>{node.ip ?? '—'}</dd>
          <dt>Wi‑Fi signal</dt><dd>{signal}{node.rssi !== null ? ` (${node.rssi} dBm)` : ''}</dd>
          <dt>Firmware</dt><dd>{node.firmware ?? '—'}</dd>
          <dt>Last activity</dt><dd>{node.lastSeenAt ? `${new Date(node.lastSeenAt).toLocaleString()} (${timeAgo(node.lastSeenAt)})` : 'never'}</dd>
          <dt>Settings</dt><dd>{node.appliedRev === node.configRev ? 'Saved on the board' : 'Waiting for the board to save them'} <span className="muted small">(v{node.appliedRev}/{node.configRev})</span></dd>
        </dl>
      </div>
    </div>
  );
}

/** One row in the boards list. */
export function BoardListItem({ node, catalog }: { node: BoardNode; catalog: Catalog }) {
  useNow(10_000);
  const s = pinStats(node, catalog);
  const cond = boardCondition(node);
  return (
    <Link href={`/boards/${node.id}`} className="board-item">
      <span className={`board-item-icon tone-${cond.tone}`} title={cond.detail}><span className="condition-led sm" /></span>
      <div className="board-item-main">
        <b>{node.name}</b>
        <span className="muted small">
          {cond.label} · {node.online ? `active ${timeAgo(node.lastSeenAt)}` : `last seen ${timeAgo(node.lastSeenAt)}`}
          {node.online && node.health?.vcc !== undefined ? ` · ${(node.health.vcc / 1000).toFixed(2)} V` : ''}
        </span>
      </div>
      <div className="board-item-meta">
        <span><b>{node.devices.length}</b> devices</span>
        <span><b>{s.used}</b>/{s.used + s.free} pins used</span>
        <SyncBadge node={node} />
      </div>
      <span className="muted">›</span>
    </Link>
  );
}

export function PendingBoard({ node, catalog, onDone }: { node: BoardNode; catalog: Catalog; onDone: () => void }) {
  const [error, setError] = useState<string | null>(null);
  async function adopt(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    try {
      await post(`/nodes/${node.id}/adopt`, { name: f.get('name'), board: f.get('board') });
      onDone();
    } catch (err) {
      setError(errorText(err));
    }
  }
  return (
    <div className="card card-pad stack">
      <div className="spread">
        <div>
          <h3 className="mono">{node.id}</h3>
          <div className="kv" style={{ marginTop: 4 }}>
            <span><span className={`dot ${node.online ? 'on' : 'off'}`} /> {node.online ? 'online' : 'offline'}</span>
            <span>firmware <b>{node.firmware ?? '?'}</b></span>
            {node.ip && <span>IP <b>{node.ip}</b></span>}
          </div>
        </div>
        <div className="row">
          <span className="badge warn">Not added yet</span>
          <button className="btn btn-small" title="Hide it until it next connects" onClick={async () => {
            try { await del(`/nodes/${node.id}`); onDone(); } catch (err) { setError(errorText(err)); }
          }}>Ignore</button>
        </div>
      </div>
      <form className="form-grid" onSubmit={adopt}>
        <label className="field">Give it a name<input name="name" placeholder="Living room switchboard" required maxLength={60} /></label>
        <label className="field">Which board is it?
          <select name="board" defaultValue={node.board}>
            {catalog.boards.map((b) => <option key={b.type} value={b.type}>{b.name}</option>)}
          </select>
        </label>
        <button className="btn btn-primary">Add to my home</button>
      </form>
      {error && <div className="alert">{error}</div>}
    </div>
  );
}

export function describeState(catalog: Catalog, d: NodeDevice): string {
  if (!d.state) return '—';
  const def = catalog.deviceTypes.find((t) => t.type === d.type);
  if (def?.controllable) return d.state.on ? 'On' : 'Off';
  if (d.type === 'contact') return contactText(d.settings, d.state.active);
  if (d.type === 'analog') return d.state.level === undefined ? '—' : `${d.state.level}% ${analogLabel(d.settings)}`;
  return (def?.stateFields ?? [])
    .filter((f) => d.state![f.key] !== undefined)
    .map((f) => `${d.state![f.key]}${f.unit ?? ''}`)
    .join(' · ') || '—';
}

export function SyncBadge({ node }: { node: BoardNode }) {
  if (node.configError) return <span className="badge bad" title={node.configError}>Settings refused</span>;
  if (node.appliedRev === node.configRev) return <span className="badge ok" title="The board is running the latest devices and pins you set here">Settings saved</span>;
  return <span className="badge warn">{node.online ? 'Saving to board…' : 'Will update when online'}</span>;
}

export type BoardTab = 'overview' | 'devices' | 'pins' | 'network' | 'logs';

export function BoardDetail({ node, catalog, rooms, reload, tab, onTab, onForgotten }: {
  node: BoardNode; catalog: Catalog; rooms: Room[]; reload: () => void;
  tab: BoardTab; onTab: (t: BoardTab) => void; onForgotten: () => void;
}) {
  const [mode, setMode] = useState<'none' | 'device' | 'button' | { edit: NodeDevice }>('none');
  const [error, setError] = useState<string | null>(null);
  useNow(10_000);
  const boardName = catalog.boards.find((b) => b.type === node.board)?.name ?? node.board;
  const pinName = (gpio: number) => {
    const p = catalog.boards.find((b) => b.type === node.board)?.pins.find((x) => x.gpio === gpio);
    return p ? `${p.label} (GPIO ${gpio})` : `GPIO ${gpio}`;
  };
  const roomName = (id: string | null) => rooms.find((r) => r.id === id)?.name ?? '—';
  const run = async (fn: () => Promise<unknown>) => {
    setError(null);
    try { await fn(); reload(); } catch (err) { setError(errorText(err)); }
  };

  const addDevice = async (v: DeviceFormValues) => {
    await post(`/nodes/${node.id}/devices`, { ...v });
    setMode('none');
    reload();
  };
  const editDevice = (d: NodeDevice) => async (v: DeviceFormValues) => {
    await patch(`/devices/${d.id}`, { name: v.name, pin: v.pin, activeLow: v.activeLow, roomId: v.roomId, aliases: v.aliases, settings: v.settings });
    setMode('none');
    reload();
  };
  const switches = node.devices.filter((d) => catalog.deviceTypes.find((t) => t.type === d.type)?.controllable);

  return (
    <div className="stack">
      <div className="board-head">
        <div>
          <Link href="/boards" className="back-link">‹ All boards</Link>
          <h1>{node.name}</h1>
          <div className="kv" style={{ marginTop: 6 }}>
            <span className={node.online ? 'text-ok' : 'text-bad'}><span className={`dot ${node.online ? 'on' : 'off'}`} /> {node.online ? 'Online' : 'Disconnected'}</span>
            <span>{boardName}</span>
            <span className="mono">{node.id}</span>
            {node.ip && <span>IP <b>{node.ip}</b></span>}
            {node.rssi !== null && <span>Wi‑Fi <b>{node.rssi} dBm</b></span>}
            <span>firmware <b>{node.firmware ?? '?'}</b></span>
          </div>
        </div>
        <div className="row">
          <PageHelp id={`board-${tab}`} title={HELP[tab].title}>{HELP[tab].body}</PageHelp>
          <SyncBadge node={node} />
          <button className="btn btn-small" onClick={() => {
            const name = prompt('Board name', node.name);
            if (name?.trim()) void run(() => patch(`/nodes/${node.id}`, { name: name.trim() }));
          }}>Rename</button>
          <button className="btn btn-small" disabled={!node.online} onClick={() => run(() => post(`/nodes/${node.id}/reboot`))}>Restart</button>
          <button className="btn btn-small btn-danger" onClick={() => {
            if (confirm(`Remove ${node.name} from your home? Its devices disappear from the app. The board itself keeps working and shows up again as a new board.`)) {
              del(`/nodes/${node.id}`).then(onForgotten).catch((err) => setError(errorText(err)));
            }
          }}>Remove</button>
        </div>
      </div>

      <div className="tabs" role="tablist" aria-label="Board sections">
        {TABS.map((t) => (
          <button key={t.id} role="tab" aria-selected={tab === t.id} className={`tab-btn ${tab === t.id ? 'active' : ''}`} onClick={() => onTab(t.id)}>
            {t.label}{t.id === 'devices' ? <span className="pill">{node.devices.length + node.inputs.length}</span> : null}
          </button>
        ))}
      </div>

      {tab === 'overview' && <BoardOverview node={node} catalog={catalog} onTab={onTab} reload={reload} />}
      {tab === 'pins' && <BoardDiagram node={node} catalog={catalog} />}
      {tab === 'network' && <NetworkPanel node={node} />}
      {tab === 'logs' && <LogPanel nodeId={node.id} online={node.online} />}
      {tab === 'devices' && (<div className="stack">
      {node.configError && <div className="alert">The board said: {node.configError}</div>}

      {node.devices.length > 0 ? (
        <div className="table-wrap">
          <table className="table">
            <thead><tr><th>Device</th><th>Type</th><th>Pin</th><th>Room</th><th>Now</th><th /></tr></thead>
            <tbody>
              {node.devices.map((d) => (
                <tr key={d.id}>
                  <td><b>{d.name}</b>{d.aliases.length > 0 && <div className="small muted">also: {d.aliases.join(', ')}</div>}</td>
                  <td>{d.type === 'switch' ? `Switch${d.activeLow ? ' (active low)' : ''}` : d.type === 'dht' ? `Sensor ${String(d.settings.model ?? '').toUpperCase()}` : d.type === 'contact' ? `Contact · ${String(d.settings.kind ?? '')}` : `Analog · ${analogLabel(d.settings)}`}</td>
                  <td className="mono">{pinName(d.pin)}</td>
                  <td>{roomName(d.roomId)}</td>
                  <td className="small">{describeState(catalog, d)}</td>
                  <td style={{ textAlign: 'right', whiteSpace: 'nowrap' }}>
                    <button className="btn btn-small" onClick={() => setMode({ edit: d })}>Edit</button>{' '}
                    <button className="btn btn-small btn-danger" onClick={() => {
                      if (confirm(`Remove ${d.name}?`)) void run(() => del(`/devices/${d.id}`));
                    }}>Remove</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <p className="muted">No devices on this board yet.</p>
      )}

      {node.inputs.length > 0 && (
        <div className="stack" style={{ gap: 6 }}>
          <h3>Wall buttons</h3>
          {node.inputs.map((i) => (
            <div key={i.id} className="spread small">
              <span>Button on <span className="mono">{pinName(i.pin)}</span> toggles <b>{i.targetName}</b></span>
              <button className="btn btn-small btn-danger" onClick={() => run(() => del(`/inputs/${i.id}`))}>Remove</button>
            </div>
          ))}
        </div>
      )}

      {typeof mode === 'object' && (
        <DeviceForm catalog={catalog} node={node} rooms={rooms} initial={mode.edit} submitLabel="Save changes"
                    onSubmit={editDevice(mode.edit)} onCancel={() => setMode('none')} />
      )}
      {mode === 'device' && (
        <DeviceForm catalog={catalog} node={node} rooms={rooms} submitLabel="Add device" onSubmit={addDevice} onCancel={() => setMode('none')} />
      )}
      {mode === 'button' && (
        <ButtonForm node={node} catalog={catalog} switches={switches} onCancel={() => setMode('none')}
                    onSubmit={async (pin, targetId) => { await post(`/nodes/${node.id}/inputs`, { type: 'toggle_button', pin, targetId }); setMode('none'); reload(); }} />
      )}
      {mode === 'none' && (
        <div className="row">
          <button className="btn btn-primary" onClick={() => setMode('device')}>Add device</button>
          <button className="btn" onClick={() => setMode('button')} disabled={switches.length === 0}
                  title={switches.length === 0 ? 'Add a switch first' : undefined}>Add wall button</button>
        </div>
      )}
      </div>)}
      {error && <div className="alert">{error}</div>}
    </div>
  );
}

export function ButtonForm({ node, catalog, switches, onSubmit, onCancel }: {
  node: BoardNode; catalog: Catalog; switches: NodeDevice[];
  onSubmit: (pin: number, targetId: string) => Promise<void>; onCancel: () => void;
}) {
  const pins = freePins(catalog, node, 'input');
  const [error, setError] = useState<string | null>(null);
  return (
    <form className="subtle-box stack" onSubmit={async (e) => {
      e.preventDefault();
      const f = new FormData(e.currentTarget);
      try { await onSubmit(Number(f.get('pin')), String(f.get('target'))); } catch (err) { setError(errorText(err)); }
    }}>
      <p className="small muted">A push-button wired between the pin and GND. It works even when Wi‑Fi is down.</p>
      <div className="form-grid">
        <label className="field">Pin
          <select name="pin">{pins.map((p) => <option key={p.gpio} value={p.gpio}>{p.label} (GPIO {p.gpio}){p.note ? ` — ${p.note}` : ''}</option>)}</select>
        </label>
        <label className="field">Toggles
          <select name="target">{switches.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}</select>
        </label>
      </div>
      {error && <div className="alert">{error}</div>}
      <div className="row">
        <button className="btn btn-primary" disabled={pins.length === 0}>Add button</button>
        <button type="button" className="btn" onClick={onCancel}>Cancel</button>
      </div>
    </form>
  );
}
