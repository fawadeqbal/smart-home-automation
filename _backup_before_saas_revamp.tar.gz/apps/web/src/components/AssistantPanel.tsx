'use client';
import { FormEvent, useEffect, useRef, useState } from 'react';
import { errorText, post } from '@/lib/api';
import { Icon } from './Icon';
import { Spinner } from './Loader';

interface Line {
  who: 'me' | 'bot';
  text: string;
  audio?: string | null;
}
interface Reply {
  heard?: string;
  reply: string;
  audio?: string | null;
}

const MAX_RECORDING_MS = 15_000;

/** Talk (tap to start, tap to stop) or type to the assistant. Replies are spoken and shown. */
export function AssistantPanel() {
  const [lines, setLines] = useState<Line[]>([]);
  const [phase, setPhase] = useState<'idle' | 'recording' | 'thinking'>('idle');
  const [error, setError] = useState<string | null>(null);
  const [text, setText] = useState('');
  const [micOk, setMicOk] = useState(true);
  const [notice, setNotice] = useState<string | null>(null);
  const player = useRef<HTMLAudioElement | null>(null);
  const recorder = useRef<MediaRecorder | null>(null);
  const stopTimer = useRef<ReturnType<typeof setTimeout>>(undefined);
  const logRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Browsers allow the microphone only on https:// or http://localhost
    setMicOk(window.isSecureContext && !!navigator.mediaDevices?.getUserMedia && typeof MediaRecorder !== 'undefined');
  }, []);
  useEffect(() => {
    logRef.current?.scrollTo({ top: logRef.current.scrollHeight, behavior: 'smooth' });
  }, [lines]);

  /** One player, created during a click: browsers only allow sound that a click started. */
  function unlockSound() {
    if (!player.current) player.current = new Audio();
    const p = player.current;
    if (p.paused && !p.src) {
      // a tiny silent WAV, played inside the click, unlocks later playback on Safari/Firefox too
      p.src = 'data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEAQB8AAIA+AAACABAAZGF0YQAAAAA=';
      void p.play().catch(() => undefined);
    }
  }

  function play(audio?: string | null) {
    setNotice(null);
    if (!audio) {
      setNotice('No voice for this reply: the assistant could not make speech. Check the assistant window for "Piper voice unavailable".');
      return;
    }
    const p = player.current ?? (player.current = new Audio());
    p.src = `data:audio/wav;base64,${audio}`;
    p.play().catch((err: Error) => {
      console.warn('[assistant] could not play the reply:', err);
      setNotice('The browser blocked the sound. Tap 🔊 next to the reply to hear it.');
    });
  }

  async function send(request: () => Promise<Reply>, shown?: string) {
    setPhase('thinking');
    setError(null);
    if (shown) setLines((l) => [...l, { who: 'me', text: shown }]);
    try {
      const reply = await request();
      setLines((l) => [...l, ...(reply.heard && !shown ? [{ who: 'me' as const, text: reply.heard }] : []), { who: 'bot', text: reply.reply, audio: reply.audio }]);
      play(reply.audio);
    } catch (err) {
      setError(errorText(err));
    } finally {
      setPhase('idle');
    }
  }

  async function startRecording() {
    setError(null);
    unlockSound();
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true } });
      const chunks: Blob[] = [];
      const rec = new MediaRecorder(stream);
      rec.ondataavailable = (e) => e.data.size && chunks.push(e.data);
      rec.onstop = () => {
        stream.getTracks().forEach((t) => t.stop());
        const blob = new Blob(chunks, { type: rec.mimeType || 'audio/webm' });
        if (blob.size < 1000) {
          setPhase('idle');
          return;
        }
        const form = new FormData();
        form.append('audio', blob, 'speech');
        void send(() => post<Reply>('/assistant/voice', form));
      };
      recorder.current = rec;
      rec.start();
      setPhase('recording');
      stopTimer.current = setTimeout(stopRecording, MAX_RECORDING_MS);
    } catch {
      setError('Microphone not available. Allow microphone access in the browser, or type instead.');
    }
  }

  function stopRecording() {
    clearTimeout(stopTimer.current);
    if (recorder.current?.state === 'recording') recorder.current.stop();
  }

  function submit(e: FormEvent) {
    e.preventDefault();
    const value = text.trim();
    if (!value || phase !== 'idle') return;
    unlockSound();
    setText('');
    void send(() => post<Reply>('/assistant/chat', { text: value, speak: true }), value);
  }

  const label = phase === 'recording' ? 'Listening… tap to send' : phase === 'thinking' ? 'Thinking…' : 'Tap to talk';

  return (
    <section className="assistant" aria-label="Assistant">
      {lines.length > 0 && <div className="assistant-head">
        <b>Assistant</b>
        {lines.length > 0 && (
          <button className="link-btn small" onClick={() => { setLines([]); void post('/assistant/reset').catch(() => undefined); }}>
            New conversation
          </button>
        )}
      </div>}
      {(lines.length > 0 || phase === 'thinking') && (
        <div className="chat-log" ref={logRef}>
          {lines.map((l, i) => (
            <div key={i} className={`bubble ${l.who}`}>
              {l.text}
              {l.who === 'bot' && l.audio && (
                <button className="replay" onClick={() => play(l.audio)}
                        aria-label="Play this reply" title="Play this reply"><Icon name="volume-2" size={14} /></button>
              )}
            </div>
          ))}
          {phase === 'thinking' && <div className="bubble bot typing" aria-label="Assistant is thinking"><i /><i /><i /></div>}
        </div>
      )}
      <div className="assistant-bar">
        <button
          className={`mic ${phase === 'recording' ? 'recording' : ''}`}
          onClick={phase === 'recording' ? stopRecording : startRecording}
          disabled={!micOk || phase === 'thinking'}
          aria-label={label}
          title={micOk ? label : 'Voice needs https:// or http://localhost. Typing works everywhere.'}
        >
          {phase === 'thinking' ? <Spinner size={18} /> : <Icon name={phase === 'recording' ? 'square' : 'mic'} size={19} />}
        </button>
        <form onSubmit={submit} className="assistant-form">
          <input
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder={micOk ? `${label}, or type: "turn on the bulb"` : 'Type: "turn on the bulb"'}
            disabled={phase !== 'idle'}
            aria-label="Message to the assistant"
          />
          <button className="send-btn" disabled={phase !== 'idle' || !text.trim()} aria-label="Send"><Icon name="arrow-up" size={18} /></button>
        </form>
      </div>
      {!micOk && <p className="assistant-note">Voice works on https:// or http://localhost. On this address you can type.</p>}
      {notice && <p className="assistant-note">{notice}</p>}
      {error && <div className="alert assistant-note">{error}</div>}
    </section>
  );
}
