'use client';
import { FormEvent, useEffect, useState } from 'react';
import { del, errorText, get, post } from '@/lib/api';
import { timeAgo } from '@/lib/hooks';
import { useLive } from '@/lib/live';
import type { BoardNode } from '@/lib/types';
import { Tip } from './Help';
import { Spinner } from './Loader';

interface Image { id: string; version: string; notes: string; size: number; md5: string; createdAt: string }

/** Update a board's firmware over Wi‑Fi: upload a build once, then install it on any board. */
export function FirmwarePanel({ node }: { node: BoardNode }) {
  const [images, setImages] = useState<Image[] | null>(null);
  const [uploading, setUploading] = useState(false);
  const [installing, setInstalling] = useState<string | null>(null);
  const [message, setMessage] = useState<{ ok: boolean; text: string } | null>(null);
  const load = () => get<Image[]>('/firmware').then(setImages).catch((e) => setMessage({ ok: false, text: errorText(e) }));
  useEffect(() => { void load(); }, []);

  // the board reports the result, then restarts and announces its new version
  useLive('node.network', (e: { nodeId: string; ota?: { ok: boolean; version: string; message: string } }) => {
    if (e.nodeId !== node.id || !e.ota) return;
    setMessage({ ok: e.ota.ok, text: e.ota.ok ? `Firmware ${e.ota.version} installed — the board is restarting.` : `Update failed: ${e.ota.message}` });
    if (!e.ota.ok) setInstalling(null);
  });
  useEffect(() => {
    if (installing && node.firmware === installing) {
      setMessage({ ok: true, text: `${node.name} now runs firmware ${installing}.` });
      setInstalling(null);
    }
  }, [node.firmware, installing, node.name]);

  async function upload(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    setUploading(true);
    setMessage(null);
    try {
      await post('/firmware', new FormData(form));
      form.reset();
      await load();
    } catch (err) {
      setMessage({ ok: false, text: errorText(err) });
    } finally {
      setUploading(false);
    }
  }

  async function install(img: Image) {
    if (!confirm(`Install firmware ${img.version} on ${node.name}?\n\nIt downloads over Wi‑Fi, checks the file, installs and restarts (about 30–60 seconds). Lights keep their last state. Don’t unplug it meanwhile.`)) return;
    setMessage(null);
    try {
      const r = await post<{ version: string; url: string }>(`/nodes/${node.id}/update`, { firmwareId: img.id });
      setInstalling(r.version);
      setMessage({ ok: true, text: `Sent. The board downloads it from ${r.url}…` });
    } catch (err) {
      setMessage({ ok: false, text: errorText(err) });
    }
  }

  return (
    <div className="card card-pad stack">
      <div className="spread">
        <h3>Firmware <Tip>The program running on the board. Update it over Wi‑Fi — no USB cable needed once the board runs firmware 2.2 or newer.</Tip></h3>
        <span className="small muted">This board runs <b className="mono">{node.firmware ?? '?'}</b></span>
      </div>

      {installing && <div className="notice row"><Spinner /> Updating to {installing}… keep the board powered.</div>}
      {message && !installing && <div className={`board-status ${message.ok ? 'ok' : 'bad'}`}><span className={`live-dot ${message.ok ? '' : 'off'}`} />{message.text}</div>}

      {images && images.length > 0 && (
        <div className="fw-list">
          {images.map((img) => (
            <div key={img.id} className="fw-row">
              <div className="stack-tight">
                <b className="mono">{img.version}{img.version === node.firmware ? ' · installed' : ''}</b>
                <span className="small muted">{Math.round(img.size / 1024)} KB · uploaded {timeAgo(img.createdAt)}{img.notes ? ` · ${img.notes}` : ''}</span>
              </div>
              <div className="row" style={{ flexWrap: 'nowrap' }}>
                <button className="btn btn-small btn-primary" disabled={!node.online || !!installing || img.version === node.firmware} onClick={() => void install(img)}>Install</button>
                <button className="icon-btn" aria-label={`Delete ${img.version}`} onClick={() => confirm(`Delete firmware ${img.version}?`) && void del(`/firmware/${img.id}`).then(load)}>×</button>
              </div>
            </div>
          ))}
        </div>
      )}

      <form className="subtle-box stack" onSubmit={upload}>
        <b className="small">Upload a new build</b>
        <p className="small muted">In Arduino: <b>Sketch → Export Compiled Binary</b>, then pick <span className="mono">home_node.ino.bin</span> from the sketch’s <span className="mono">build</span> folder.</p>
        <div className="form-grid">
          <label className="field">File (.bin)<input name="file" type="file" accept=".bin,application/octet-stream" required /></label>
          <label className="field">Version<input name="version" required placeholder="2.2.0" pattern="[\w.\-+]{1,40}" /></label>
          <label className="field">Notes (optional)<input name="notes" maxLength={300} placeholder="What changed" /></label>
        </div>
        <button className="btn btn-small" style={{ alignSelf: 'flex-start' }} disabled={uploading}>{uploading ? 'Uploading…' : 'Upload'}</button>
      </form>
      <p className="small muted">The board downloads from this PC’s address on port 4000 — allow it once in Windows Firewall (like port 1883). Set <span className="mono">PUBLIC_API_URL</span> in .env if the address is wrong.</p>
    </div>
  );
}
