'use client';
import { FormEvent, useEffect, useState } from 'react';
import { errorText, get, post } from '@/lib/api';
import { timeAgo } from '@/lib/hooks';
import { useLive } from '@/lib/live';
import type { BoardNode } from '@/lib/types';
import { Tip } from './Help';
import { Loader, Spinner } from './Loader';

interface Seen { ssid: string; rssi: number; channel: number; secure: boolean }
interface NetInfo { scan?: Seen[]; scanAt?: string; result?: { ok: boolean; ssid: string; message: string }; resultAt?: string }

function bars(rssi?: number) {
  return rssi === undefined ? 0 : rssi > -55 ? 4 : rssi > -67 ? 3 : rssi > -75 ? 2 : rssi > -85 ? 1 : 0;
}
const WORD = ['Very weak', 'Weak', 'Fair', 'Good', 'Excellent'];

function Bars({ rssi }: { rssi?: number }) {
  const b = bars(rssi);
  return <span className={`bars ${b >= 2 ? '' : b === 1 ? 'warn' : 'bad'}`} aria-label={WORD[b]}>{[1, 2, 3, 4].map((i) => <i key={i} className={i <= b ? 'on' : ''} />)}</span>;
}

/** Network tab: what the board is connected to, nearby networks, and moving it to another Wi‑Fi. */
export function NetworkPanel({ node }: { node: BoardNode }) {
  const [info, setInfo] = useState<NetInfo | null>(null);
  const [scanning, setScanning] = useState(false);
  const [pick, setPick] = useState<Seen | { ssid: string; secure: boolean; manual: true } | null>(null);
  const [switching, setSwitching] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const h = node.health;

  useEffect(() => {
    get<NetInfo>(`/nodes/${node.id}/network`).then(setInfo).catch((e) => setError(errorText(e)));
  }, [node.id]);

  useLive('node.network', (e: NetInfo & { nodeId: string }) => {
    if (e.nodeId !== node.id) return;
    setInfo(e);
    if (e.scan) setScanning(false);
    if (e.result && switching && e.result.ssid === switching) setSwitching(null);
  });

  async function scan() {
    setError(null);
    setScanning(true);
    try {
      await post(`/nodes/${node.id}/wifi/scan`);
      setTimeout(() => setScanning(false), 15000); // give up waiting after 15 s
    } catch (e) {
      setScanning(false);
      setError(errorText(e));
    }
  }

  async function connect(ev: FormEvent<HTMLFormElement>) {
    ev.preventDefault();
    if (!pick) return;
    const f = new FormData(ev.currentTarget);
    const ssid = 'manual' in pick ? String(f.get('ssid') ?? '').trim() : pick.ssid;
    const password = String(f.get('password') ?? '');
    if (!confirm(`Move ${node.name} to "${ssid}"?\n\nIt disconnects for up to 30 seconds. If it cannot join "${ssid}", it goes back to "${h?.ssid ?? 'its current network'}" by itself.`)) return;
    setError(null);
    try {
      await post(`/nodes/${node.id}/wifi`, { ssid, password });
      setSwitching(ssid);
      setPick(null);
    } catch (e) {
      setError(errorText(e));
    }
  }

  async function resetWifi() {
    if (!confirm(`Make ${node.name} forget its Wi‑Fi?\n\nIt restarts as the hotspot "HomeNode-${node.id.replace('esp-', '')}". It will be OFFLINE until someone joins that hotspot with a phone and enters a Wi‑Fi again.`)) return;
    try { await post(`/nodes/${node.id}/wifi/reset`); } catch (e) { setError(errorText(e)); }
  }

  if (!info && !error) return <Loader label="Loading network…" />;
  const sorted = [...(info?.scan ?? [])].sort((a, b) => b.rssi - a.rssi);
  const current = h?.ssid;

  return (
    <div className="stack">
      {switching && (
        <div className="notice row"><Spinner /> Moving to “{switching}”… The board is briefly offline; this takes up to 30 seconds.</div>
      )}
      {info?.result && !switching && (
        <div className={info.result.ok ? 'board-status ok' : 'board-status bad'}>
          <span className={`live-dot ${info.result.ok ? '' : 'off'}`} />
          <span>
            <b>{info.result.ok ? `Now on “${info.result.ssid}”` : `Could not move to “${info.result.ssid}”`}</b> — {info.result.message}
            {info.resultAt && <span className="muted"> · {timeAgo(info.resultAt)}</span>}
          </span>
        </div>
      )}

      <div className="card card-pad stack">
        <div className="spread">
          <h3>Connected to</h3>
          {!node.online && <span className="badge bad">Board offline</span>}
        </div>
        {h?.ssid ? (
          <div className="net-current">
            <span className="net-icon"><Bars rssi={h.rssi} /></span>
            <div className="stack-tight">
              <b className="net-ssid">{h.ssid}</b>
              <span className="muted small">{WORD[bars(h.rssi)]} signal ({h.rssi} dBm) · channel {h.channel ?? '—'}</span>
            </div>
          </div>
        ) : (
          <p className="muted small">Network details arrive with the board’s next health report (every minute, firmware 2.1+).</p>
        )}
        <dl className="facts">
          <dt>Board’s IP address <Tip>Its address on your home network. Your router gave it out; it can change after a restart.</Tip></dt><dd className="mono">{node.ip ?? '—'}</dd>
          <dt>Router address</dt><dd className="mono">{h?.gateway ?? '—'}</dd>
          <dt>Access point <Tip>The exact router or Wi‑Fi extender the board is joined to (its hardware address).</Tip></dt><dd className="mono">{h?.bssid ?? '—'}</dd>
          <dt>Board’s MAC address <Tip>The board’s own hardware address — useful to give it a fixed IP in your router.</Tip></dt><dd className="mono">{h?.mac ?? '—'}</dd>
        </dl>
      </div>

      <div className="card card-pad stack">
        <div className="spread">
          <div className="stack-tight">
            <h3>Nearby Wi‑Fi networks</h3>
            <span className="muted small">
              {info?.scanAt ? `Seen by the board ${timeAgo(info.scanAt)}.` : 'Ask the board which networks it can hear.'} Only 2.4 GHz networks work with this board.
            </span>
          </div>
          <button className="btn" onClick={scan} disabled={!node.online || scanning || !!switching}>
            {scanning ? <><Spinner /> Scanning…</> : 'Scan now'}
          </button>
        </div>

        {sorted.length > 0 && (
          <div className="net-list">
            {sorted.map((n) => {
              const isCurrent = n.ssid === current;
              return (
                <button key={`${n.ssid}-${n.channel}`} className={`net-item ${isCurrent ? 'current' : ''} ${pick && !('manual' in pick) && pick.ssid === n.ssid ? 'picked' : ''}`}
                        disabled={isCurrent || !node.online || !!switching} onClick={() => setPick(n)}>
                  <Bars rssi={n.rssi} />
                  <span className="net-name">{n.ssid}</span>
                  <span className="muted small">{n.secure ? '🔒' : 'open'} · ch {n.channel} · {n.rssi} dBm</span>
                  <span className="net-action">{isCurrent ? 'Connected' : 'Connect'}</span>
                </button>
              );
            })}
          </div>
        )}
        <button className="link-btn small" style={{ alignSelf: 'flex-start' }} disabled={!node.online || !!switching}
                onClick={() => setPick({ ssid: '', secure: true, manual: true })}>
          Network not listed (hidden)? Type its name
        </button>

        {pick && (
          <form className="subtle-box stack" onSubmit={connect}>
            <b>{'manual' in pick ? 'Join a network by name' : `Join “${pick.ssid}”`}</b>
            <div className="form-grid">
              {'manual' in pick && (
                <label className="field">Network name (SSID)<input name="ssid" required maxLength={32} autoComplete="off" /></label>
              )}
              {pick.secure && (
                <label className="field">Wi‑Fi password<input name="password" type="password" required minLength={8} maxLength={63} autoComplete="new-password" /></label>
              )}
            </div>
            <p className="small muted">
              The password goes only to the board and is not stored in this app. If the board can’t join within 30 seconds it returns to “{current ?? 'its current network'}”.
            </p>
            <div className="row">
              <button className="btn btn-primary">Move board to this network</button>
              <button type="button" className="btn" onClick={() => setPick(null)}>Cancel</button>
            </div>
          </form>
        )}
      </div>

      <div className="card card-pad stack danger-zone">
        <h3>Start Wi‑Fi setup again</h3>
        <p className="small muted">
          The board forgets its Wi‑Fi and opens its own hotspot <b>HomeNode‑{node.id.replace('esp-', '')}</b>. Use this when you change router or Wi‑Fi password.
          You will need a phone near the board to finish setup. You can also do this on the board: press <b>RST</b>, then hold <b>FLASH</b> for 3 seconds.
        </p>
        <button className="btn btn-danger" style={{ alignSelf: 'flex-start' }} onClick={resetWifi} disabled={!node.online}>Forget Wi‑Fi and open setup hotspot</button>
      </div>

      {error && <div className="alert">{error}</div>}
    </div>
  );
}
