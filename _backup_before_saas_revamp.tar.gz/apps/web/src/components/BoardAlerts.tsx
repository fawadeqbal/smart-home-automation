'use client';
import Link from 'next/link';
import { useEffect, useRef, useState } from 'react';
import { useLive } from '@/lib/live';

interface Alert { id: number; nodeId: string; name: string; online: boolean; at: string }

/** Pops up a notice when a board disconnects or comes back. Offline notices stay until closed. */
export function BoardAlerts() {
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const nextId = useRef(1);

  useLive('node.status', (e: { nodeId: string; online: boolean; name?: string | null; changed?: boolean; at?: string }) => {
    if (!e.changed) return;
    const alert: Alert = { id: nextId.current++, nodeId: e.nodeId, name: e.name || e.nodeId, online: e.online, at: e.at ?? new Date().toISOString() };
    // a board coming back replaces its "disconnected" notice
    setAlerts((list) => [...list.filter((a) => a.nodeId !== e.nodeId), alert].slice(-4));
  });

  // "back online" notices close themselves
  useEffect(() => {
    const timers = alerts.filter((a) => a.online).map((a) => setTimeout(() => setAlerts((l) => l.filter((x) => x.id !== a.id)), 6000));
    return () => timers.forEach(clearTimeout);
  }, [alerts]);

  if (alerts.length === 0) return null;
  return (
    <div className="toasts" aria-live="assertive">
      {alerts.map((a) => (
        <div key={a.id} className={`toast ${a.online ? 'ok' : 'bad'}`} role={a.online ? 'status' : 'alert'}>
          <span className={`live-dot ${a.online ? '' : 'off'}`} />
          <div className="toast-body">
            <b>{a.name} {a.online ? 'is back online' : 'disconnected'}</b>
            <span>
              {new Date(a.at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              {a.online ? '' : ' · its devices can’t be switched until it reconnects. '}
              {!a.online && <Link href="/boards">Open boards</Link>}
            </span>
          </div>
          <button className="icon-btn" aria-label="Close" onClick={() => setAlerts((l) => l.filter((x) => x.id !== a.id))}>×</button>
        </div>
      ))}
    </div>
  );
}
