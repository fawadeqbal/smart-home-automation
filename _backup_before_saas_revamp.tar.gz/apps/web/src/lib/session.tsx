'use client';
import { useRouter } from 'next/navigation';
import { createContext, ReactNode, useCallback, useContext, useEffect, useState } from 'react';
import { ApiError, get, post } from './api';
import type { Me } from './types';
import { Loader } from '@/components/Loader';

interface Session {
  me: Me;
  isAdmin: boolean;
  reload: () => Promise<void>;
  logout: () => Promise<void>;
}

const SessionContext = createContext<Session | null>(null);

/** Loads the signed-in person; sends them to /setup or /login when needed. */
export function SessionProvider({ children }: { children: ReactNode }) {
  const router = useRouter();
  const [me, setMe] = useState<Me | null>(null);

  const reload = useCallback(async () => {
    try {
      setMe(await get<Me>('/auth/me'));
    } catch (err) {
      if (err instanceof ApiError && err.status === 401) {
        const { setupNeeded } = await get<{ setupNeeded: boolean }>('/auth/status');
        router.replace(setupNeeded ? '/setup' : '/login');
      } else {
        throw err;
      }
    }
  }, [router]);

  useEffect(() => {
    reload().catch(() => router.replace('/login'));
  }, [reload, router]);

  const logout = useCallback(async () => {
    await post('/auth/logout').catch(() => undefined);
    router.replace('/login');
  }, [router]);

  if (!me) return <Loader full />;
  const isAdmin = me.role === 'OWNER' || me.role === 'ADMIN';
  return <SessionContext.Provider value={{ me, isAdmin, reload, logout }}>{children}</SessionContext.Provider>;
}

export function useSession(): Session {
  const session = useContext(SessionContext);
  if (!session) throw new Error('useSession outside SessionProvider');
  return session;
}
