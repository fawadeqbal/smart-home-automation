/** Shapes returned by the API (apps/api). */

export type Role = 'OWNER' | 'ADMIN' | 'MEMBER' | 'GUEST';
export type Access = 'VIEW' | 'CONTROL' | 'MANAGE';

export interface Me {
  id: string;
  name: string;
  email: string;
  role: Role;
  superAdmin?: boolean;
  home: { id: string; name: string };
  rooms: { roomId: string; access: Access }[];
}

export interface StateField {
  key: string;
  label: string;
  unit?: string;
}

export interface Device {
  id: string;
  key: string;
  name: string;
  aliases: string[];
  type: string;
  typeLabel: string;
  controllable: boolean;
  stateFields: StateField[];
  nodeId: string;
  nodeName: string;
  online: boolean;
  roomId: string | null;
  roomName: string | null;
  pin: number;
  pinLabel: string;
  activeLow: boolean;
  settings: Record<string, unknown>;
  enabled: boolean;
  state: Record<string, unknown> | null;
  source: string | null;
  updatedAt: string | null;
  access: Access;
}

export interface Room {
  id: string;
  name: string;
  order: number;
  access: Access;
}

export interface BoardPin {
  gpio: number;
  label: string;
  uses: ('output' | 'input' | 'sensor' | 'analog')[];
  note?: string;
}

export interface Catalog {
  boards: { type: string; name: string; pins: BoardPin[] }[];
  deviceTypes: { type: string; label: string; pinUse: string; controllable: boolean; hasActiveLow: boolean; stateFields: StateField[] }[];
  inputTypes: { type: string; label: string; pinUse: string }[];
}

export interface NodeDevice {
  id: string;
  key: string;
  name: string;
  type: string;
  pin: number;
  activeLow: boolean;
  roomId: string | null;
  settings: Record<string, unknown>;
  enabled: boolean;
  aliases: string[];
  state: Record<string, unknown> | null;
}

export interface BoardNode {
  id: string;
  name: string;
  board: string;
  status: 'PENDING' | 'ADOPTED';
  online: boolean;
  firmware: string | null;
  ip: string | null;
  rssi: number | null;
  lastSeenAt: string | null;
  configRev: number;
  appliedRev: number;
  configError: string | null;
  health: BoardHealth | null;
  devices: NodeDevice[];
  inputs: { id: string; type: string; pin: number; targetId: string; targetName: string; settings: Record<string, unknown> }[];
}

export interface FamilyMember {
  id: string;
  name: string;
  email: string;
  role: Role;
  disabled: boolean;
  rooms: { roomId: string; access: Access }[];
}

export interface HistoryEntry {
  state: Record<string, unknown>;
  source: string;
  at: string;
}

/** What a board reports about itself every minute (firmware 2.1+ sends all fields). */
export interface BoardHealth {
  at: string;
  rssi?: number;
  heap?: number;
  heapFrag?: number;
  maxBlock?: number;
  uptime?: number;
  vcc?: number; // millivolts
  cpuMhz?: number;
  flashKb?: number;
  sketchKb?: number;
  freeSketchKb?: number;
  reset?: string;
  ssid?: string;
  channel?: number;
  connects?: number;
  bssid?: string;
  gateway?: string;
  mac?: string;
}

export interface ScheduleAction { deviceId: string; on: boolean; deviceName: string }
export interface Schedule {
  id: string;
  name: string;
  kind: 'ONCE' | 'DAILY';
  runAt: string | null;
  time: string | null;
  days: number[];
  enabled: boolean;
  nextRunAt: string | null;
  lastRunAt: string | null;
  lastResult: string | null;
  sceneId: string | null;
  sceneName: string | null;
  actions: ScheduleAction[];
  createdBy: string;
  createdById: string;
}
export interface Scene {
  id: string;
  name: string;
  icon: string;
  createdBy: string;
  canRun: boolean;
  actions: ScheduleAction[];
}
