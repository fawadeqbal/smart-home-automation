'use client';
import { useRouter } from 'next/navigation';
import { AuthForm, Field } from '@/components/AuthForm';
import { post } from '@/lib/api';

export default function SetupPage() {
  const router = useRouter();
  return (
    <AuthForm
      title="Set up your home"
      intro="First run: create your home and the owner account. You can invite family members afterwards."
      submitLabel="Create home"
      onSubmit={async (f) => {
        await post('/auth/setup', {
          homeName: f.get('homeName'), name: f.get('name'), email: f.get('email'), password: f.get('password'),
        });
        router.replace('/boards');
      }}
    >
      <Field label="Home name" name="homeName" defaultValue="Our home" required />
      <Field label="Your name" name="name" autoComplete="name" required />
      <Field label="Email" name="email" type="email" autoComplete="email" required />
      <Field label="Password (8+ characters)" name="password" type="password" minLength={8} autoComplete="new-password" required />
    </AuthForm>
  );
}
