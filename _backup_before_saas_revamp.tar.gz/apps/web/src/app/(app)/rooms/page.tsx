'use client';
import { FormEvent, useState } from 'react';
import { PageHelp } from '@/components/Help';
import { Icon } from '@/components/Icon';
import { Loader } from '@/components/Loader';
import { del, errorText, patch, post } from '@/lib/api';
import { contactText, deviceIcon } from '@/lib/format';
import { useDevices, useLoad } from '@/lib/hooks';
import type { Device, FamilyMember, Room } from '@/lib/types';

/** A friendly icon and colour from the room's name. */
function roomLook(name: string): { icon: string; tone: string } {
  const n = name.toLowerCase();
  if (/bed|sleep|kid|child|guest/.test(n)) return { icon: 'bed', tone: 'violet' };
  if (/kitchen|dining|cook/.test(n)) return { icon: 'utensils', tone: 'amber' };
  if (/living|lounge|drawing|tv|family/.test(n)) return { icon: 'sofa', tone: 'indigo' };
  if (/bath|wash|toilet/.test(n)) return { icon: 'bath', tone: 'teal' };
  if (/garage|car|porch/.test(n)) return { icon: 'car', tone: 'slate' };
  if (/garden|lawn|roof|terrace|balcony|yard/.test(n)) return { icon: 'tree', tone: 'green' };
  return { icon: 'door-open', tone: 'indigo' };
}

function initials(name: string) {
  return name.split(/\s+/).filter(Boolean).slice(0, 2).map((w) => w[0]!.toUpperCase()).join('') || '?';
}

function summary(list: Device[]) {
  const on = list.filter((d) => d.controllable && d.online && d.state?.on).length;
  const offline = list.filter((d) => !d.online).length;
  const temp = list.find((d) => typeof d.state?.temperature === 'number')?.state?.temperature as number | undefined;
  const hum = list.find((d) => typeof d.state?.humidity === 'number')?.state?.humidity as number | undefined;
  const alert = list.find((d) => d.type === 'contact' && d.state?.active && ['door', 'window', 'leak'].includes(String(d.settings.kind)));
  return { on, offline, temp, hum, alert };
}

function RoomCard({ room, devices, people, onRename, onDelete }: {
  room: Room; devices: Device[]; people: FamilyMember[];
  onRename: (name: string) => Promise<void>; onDelete: () => void;
}) {
  const [editing, setEditing] = useState(false);
  const look = roomLook(room.name);
  const s = summary(devices);

  return (
    <article className={`room-card room-${look.tone}`}>
      <div className="room-top">
        <span className="room-icon"><Icon name={look.icon} size={22} /></span>
        <div className="room-actions">
          <button className="icon-btn" title="Rename" aria-label={`Rename ${room.name}`} onClick={() => setEditing(true)}><Icon name="pencil" size={15} /></button>
          <button className="icon-btn" title="Delete" aria-label={`Delete ${room.name}`} onClick={onDelete}><Icon name="trash" size={15} /></button>
        </div>
      </div>

      {editing ? (
        <form className="room-rename" onSubmit={async (e) => {
          e.preventDefault();
          const name = String(new FormData(e.currentTarget).get('name')).trim();
          if (name && name !== room.name) await onRename(name);
          setEditing(false);
        }}>
          <input name="name" defaultValue={room.name} autoFocus maxLength={60} aria-label="Room name"
                 onKeyDown={(e) => e.key === 'Escape' && setEditing(false)} />
          <button className="btn btn-small btn-primary">Save</button>
        </form>
      ) : (
        <h3 className="room-name">{room.name}</h3>
      )}

      <p className="room-line">
        {devices.length === 0 ? 'No devices yet'
          : `${devices.length} device${devices.length === 1 ? '' : 's'}${s.on ? ` · ${s.on} on` : ''}${s.offline ? ` · ${s.offline} offline` : ''}`}
      </p>

      {(s.temp !== undefined || s.alert) && (
        <div className="room-chips">
          {s.temp !== undefined && <span className="room-chip"><Icon name="thermometer" size={13} />{s.temp.toFixed(1)}°{s.hum !== undefined ? ` · ${Math.round(s.hum)}%` : ''}</span>}
          {s.alert && <span className="room-chip alert"><Icon name={deviceIcon('contact', s.alert.settings)} size={13} />{s.alert.name}: {contactText(s.alert.settings, true)}</span>}
        </div>
      )}

      <div className="room-foot">
        <div className="room-devices" aria-label="Devices">
          {devices.slice(0, 6).map((d) => (
            <span key={d.id} className={`room-dev ${d.controllable && d.online && d.state?.on ? 'on' : ''} ${d.online ? '' : 'off'}`} title={`${d.name}${d.online ? '' : ' (offline)'}`}>
              <Icon name={deviceIcon(d.type, d.settings)} size={13} />
            </span>
          ))}
          {devices.length > 6 && <span className="room-dev more">+{devices.length - 6}</span>}
        </div>
        <div className="room-people" title={people.length ? people.map((p) => p.name).join(', ') : 'Only owners and admins'}>
          {people.slice(0, 3).map((p) => <span key={p.id} className="room-avatar">{initials(p.name)}</span>)}
          {people.length > 3 && <span className="room-avatar more">+{people.length - 3}</span>}
          {people.length === 0 && <span className="muted small">Admins only</span>}
        </div>
      </div>
    </article>
  );
}

export default function RoomsPage() {
  const rooms = useLoad<Room[]>('/rooms');
  const users = useLoad<FamilyMember[]>('/users');
  const { devices } = useDevices();
  const [adding, setAdding] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const run = async (fn: () => Promise<unknown>) => {
    setError(null);
    try { await fn(); await rooms.reload(); } catch (err) { setError(errorText(err)); }
  };

  async function add(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    const name = String(new FormData(form).get('name')).trim();
    if (!name) return;
    await run(() => post('/rooms', { name, order: rooms.data?.length ?? 0 }));
    form.reset();
    setAdding(false);
  }

  const unassigned = devices?.filter((d) => !d.roomId) ?? [];

  return (
    <>
      <div className="page-head">
        <div>
          <h1>Rooms</h1>
          <p className="muted">Group your devices by room, and choose who can use each one.</p>
        </div>
        <PageHelp id="rooms" title="Why rooms?">
          <ul>
            <li>Devices are shown on Home grouped by room.</li>
            <li>Family access is given per room — e.g. children can control their bedroom but only see the kitchen. The faces on a card are who has access.</li>
            <li>Put a device in a room when you add it (board → Devices), or edit it later.</li>
          </ul>
        </PageHelp>
      </div>

      {error && <div className="alert section">{error}</div>}
      {!rooms.data && !rooms.error && <Loader label="Loading rooms…" />}

      {rooms.data && (
        <div className="room-grid">
          {rooms.data.map((r) => (
            <RoomCard
              key={r.id}
              room={r}
              devices={devices?.filter((d) => d.roomId === r.id) ?? []}
              people={(users.data ?? []).filter((u) => !u.disabled && u.role !== 'OWNER' && u.role !== 'ADMIN' && u.rooms.some((a) => a.roomId === r.id))}
              onRename={(name) => run(() => patch(`/rooms/${r.id}`, { name }))}
              onDelete={() => {
                if (confirm(`Delete ${r.name}? Its devices are kept, without a room.`)) void run(() => del(`/rooms/${r.id}`));
              }}
            />
          ))}

          {adding ? (
            <form className="room-card room-new-form" onSubmit={add}>
              <span className="room-icon"><Icon name="plus" size={22} /></span>
              <label className="field">Room name
                <input name="name" placeholder="e.g. Bedroom, Kitchen" required maxLength={60} autoFocus
                       onKeyDown={(e) => e.key === 'Escape' && setAdding(false)} />
              </label>
              <div className="row">
                <button className="btn btn-primary btn-small">Add room</button>
                <button type="button" className="btn btn-small" onClick={() => setAdding(false)}>Cancel</button>
              </div>
            </form>
          ) : (
            <button className="room-card room-add" onClick={() => setAdding(true)}>
              <span className="room-icon"><Icon name="plus" size={22} /></span>
              <b>Add a room</b>
              <span className="muted small">Bedroom, kitchen, garage…</span>
            </button>
          )}
        </div>
      )}

      {unassigned.length > 0 && (
        <p className="muted small section" style={{ marginTop: 20 }}>
          {unassigned.length} device{unassigned.length === 1 ? ' is' : 's are'} not in a room ({unassigned.map((d) => d.name).join(', ')}) — only owners and admins see {unassigned.length === 1 ? 'it' : 'them'}. Set a room in the board’s Devices tab.
        </p>
      )}
    </>
  );
}
