'use client';
import Link from 'next/link';
import { useState } from 'react';
import { BoardListItem, PendingBoard } from '@/components/BoardParts';
import { Loader } from '@/components/Loader';
import { post } from '@/lib/api';
import { useLoad } from '@/lib/hooks';
import { useLive } from '@/lib/live';
import type { BoardNode, Catalog } from '@/lib/types';
import { PageHelp, Tip } from '@/components/Help';

export default function BoardsPage() {
  const nodes = useLoad<BoardNode[]>('/nodes');
  const catalog = useLoad<Catalog>('/catalog');
  const [scanning, setScanning] = useState(false);
  useLive('nodes.changed', () => void nodes.reload());
  useLive('node.status', () => void nodes.reload());
  useLive('node.health', (e: { nodeId: string; health: BoardNode['health']; lastSeenAt: string }) =>
    nodes.setData((list) => list?.map((n) => (n.id === e.nodeId ? { ...n, health: e.health, lastSeenAt: e.lastSeenAt } : n)) ?? list));

  const pending = nodes.data?.filter((n) => n.status === 'PENDING') ?? [];
  const adopted = nodes.data?.filter((n) => n.status === 'ADOPTED') ?? [];

  async function scan() {
    setScanning(true);
    await post('/nodes/scan').catch(() => undefined);
    setTimeout(() => { void nodes.reload(); setScanning(false); }, 1200);
  }

  if (!nodes.data || !catalog.data) {
    return nodes.error ?? catalog.error
      ? <div className="alert">{nodes.error ?? catalog.error}</div>
      : <Loader label="Loading boards…" />;
  }

  return (
    <>
      <div className="page-head">
        <div>
          <h1>Boards</h1>
          <p className="muted">The small Wi‑Fi controllers wired behind your switchboards. Open one to see what is connected to it.</p>
        </div>
        <PageHelp id="boards" title="What are boards?">
          <p>Each board is a NodeMCU (ESP8266) controller. Lights, sensors and wall buttons are wired to its pins, and it talks to this app over Wi‑Fi.</p>
          <ul>
            <li>The coloured light shows its condition: <b className="text-ok">green</b> healthy, <b className="text-warn">amber</b> needs attention, <b className="text-bad">red</b> disconnected.</li>
            <li>A newly powered board appears under <b>New board found</b>. Name it and press <b>Add to my home</b>.</li>
            <li>Don’t see it? Press <b>Look for new boards</b>, and check it joined your Wi‑Fi (its blue light stops blinking).</li>
          </ul>
        </PageHelp>
        <div className="row">
          <button className="btn" onClick={scan} disabled={scanning}>{scanning ? 'Looking…' : 'Look for new boards'}</button>
          <Link className="btn btn-primary" href="/boards/new">+ Add a board</Link>
        </div>
      </div>

      {pending.length > 0 && (
        <section className="stack">
          <h2>New board found</h2>
          {pending.map((n) => <PendingBoard key={n.id} node={n} catalog={catalog.data!} onDone={nodes.reload} />)}
        </section>
      )}

      {nodes.data.length === 0 && (
        <div className="empty">
          No boards yet. Power a board with the home firmware and connect it to Wi‑Fi and this server
          (or run <span className="mono">python tools/fake-node/fake_node.py</span>). It appears here within seconds.
        </div>
      )}

      {adopted.length > 0 && (
        <section className="section">
          <div className="section-head"><h2>Your boards</h2><span className="pill">{adopted.filter((n) => n.online).length} of {adopted.length} online</span></div>
          <div className="board-list">
            {adopted.map((n) => <BoardListItem key={n.id} node={n} catalog={catalog.data!} />)}
          </div>
        </section>
      )}
    </>
  );
}
