'use client';
import { useParams, useRouter, useSearchParams } from 'next/navigation';
import { BoardDetail, BoardTab } from '@/components/BoardParts';
import { Loader } from '@/components/Loader';
import { useLoad } from '@/lib/hooks';
import { useLive } from '@/lib/live';
import type { BoardNode, Catalog, Room } from '@/lib/types';

const TABS: BoardTab[] = ['overview', 'devices', 'pins', 'network', 'logs'];

export default function BoardPage() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const params = useSearchParams();
  const tab = (TABS.includes(params.get('tab') as BoardTab) ? params.get('tab') : 'overview') as BoardTab;

  const nodes = useLoad<BoardNode[]>('/nodes');
  const catalog = useLoad<Catalog>('/catalog');
  const rooms = useLoad<Room[]>('/rooms');
  useLive('nodes.changed', () => void nodes.reload());
  useLive('node.status', () => void nodes.reload());
  useLive('node.health', (e: { nodeId: string; health: BoardNode['health']; lastSeenAt: string }) =>
    nodes.setData((list) => list?.map((n) => (n.id === e.nodeId ? { ...n, health: e.health, lastSeenAt: e.lastSeenAt } : n)) ?? list));

  if (!nodes.data || !catalog.data || !rooms.data) {
    const error = nodes.error ?? catalog.error ?? rooms.error;
    return error ? <div className="alert">{error}</div> : <Loader label="Loading board…" />;
  }
  const node = nodes.data.find((n) => n.id === decodeURIComponent(id) && n.status === 'ADOPTED');
  if (!node) {
    return <div className="empty">This board is not in your home any more. <a href="/boards">Back to boards</a></div>;
  }
  return (
    <BoardDetail
      node={node} catalog={catalog.data} rooms={rooms.data} reload={nodes.reload}
      tab={tab}
      onTab={(t) => router.replace(`/boards/${encodeURIComponent(node.id)}${t === 'overview' ? '' : `?tab=${t}`}`, { scroll: false })}
      onForgotten={() => router.push('/boards')}
    />
  );
}
