'use client';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { FormEvent, useEffect, useState } from 'react';
import { Spinner } from '@/components/Loader';
import { errorText, get, post } from '@/lib/api';
import { useLoad } from '@/lib/hooks';
import { useLive } from '@/lib/live';
import type { BoardNode, Catalog } from '@/lib/types';

interface SetupInfo { server: string | null; port: number; login: string; password: string; encrypted: boolean }

const STEPS = ['Firmware', 'Power on', 'Wi‑Fi setup', 'Find it', 'Done'];

function Copy({ value, secret = false }: { value: string; secret?: boolean }) {
  const [shown, setShown] = useState(!secret);
  const [copied, setCopied] = useState(false);
  return (
    <span className="copy-field">
      <span className="mono">{shown ? value : '••••••••••'}</span>
      {secret && <button type="button" className="link-btn small" onClick={() => setShown((v) => !v)}>{shown ? 'Hide' : 'Show'}</button>}
      <button type="button" className="link-btn small" onClick={async () => {
        try { await navigator.clipboard.writeText(value); setCopied(true); setTimeout(() => setCopied(false), 1500); } catch { setShown(true); }
      }}>{copied ? 'Copied ✓' : 'Copy'}</button>
    </span>
  );
}

/** Step-by-step: from a new NodeMCU in your hand to a board in your home. */
export default function AddBoardWizard() {
  const router = useRouter();
  const [step, setStep] = useState(0);
  const [info, setInfo] = useState<SetupInfo | null>(null);
  const nodes = useLoad<BoardNode[]>('/nodes');
  const catalog = useLoad<Catalog>('/catalog');
  const [known] = useState(() => new Set<string>());
  const [error, setError] = useState<string | null>(null);
  useLive('nodes.changed', () => void nodes.reload());
  useLive('node.status', () => void nodes.reload());

  useEffect(() => { get<SetupInfo>('/nodes/setup-info').then(setInfo).catch((e) => setError(errorText(e))); }, []);
  // boards that were already waiting before step 4 are listed too, but new ones are highlighted
  useEffect(() => { if (step < 3) nodes.data?.forEach((n) => known.add(n.id)); }, [nodes.data, step, known]);
  useEffect(() => { if (step === 3) void post('/nodes/scan').catch(() => undefined); }, [step]);

  const pending = (nodes.data ?? []).filter((n) => n.status === 'PENDING');

  async function adopt(e: FormEvent<HTMLFormElement>, node: BoardNode) {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    setError(null);
    try {
      await post(`/nodes/${node.id}/adopt`, { name: f.get('name'), board: f.get('board') });
      router.push(`/boards/${node.id}?tab=devices`);
    } catch (err) {
      setError(errorText(err));
    }
  }

  return (
    <div className="wizard">
      <Link href="/boards" className="back-link">‹ Boards</Link>
      <h1>Add a board</h1>
      <p className="muted">Five short steps from a new NodeMCU to lights you can switch from here. Takes about 10 minutes the first time.</p>

      <ol className="stepper" aria-label="Progress">
        {STEPS.map((s, i) => (
          <li key={s} className={i === step ? 'current' : i < step ? 'done' : ''}>
            <button type="button" onClick={() => i < step && setStep(i)} disabled={i > step}>
              <span className="step-n">{i < step ? '✓' : i + 1}</span><span className="step-l">{s}</span>
            </button>
          </li>
        ))}
      </ol>

      <div className="card card-pad stack wizard-body">
        {step === 0 && (
          <>
            <h2>1 · Put the home firmware on the board</h2>
            <p>Only once per board, with a USB cable. After this, updates come over Wi‑Fi from the board’s page.</p>
            <ol className="wizard-list">
              <li>Install <b>Arduino IDE 2</b>, then in <b>Boards Manager</b> add <b>esp8266</b> and in <b>Library Manager</b>: ArduinoJson, PubSubClient, WiFiManager (tzapu), DHT sensor library.</li>
              <li>Open <span className="mono">firmware/home_node/home_node.ino</span>. Choose <b>Tools → Board → NodeMCU 1.0 (ESP‑12E Module)</b>, your COM port, and <b>Upload Speed 115200</b>.</li>
              <li>Press <b>Upload</b> and wait for “Hard resetting via RTS pin”.</li>
            </ol>
            <div className="notice small">“A device attached to the system is not functioning” on upload? Windows updated the USB driver — roll the CH340 driver back to version 3.5 (see Help).</div>
            <div className="row"><button className="btn btn-primary" onClick={() => setStep(1)}>Done, next</button><button className="btn" onClick={() => setStep(1)}>It already has the firmware</button></div>
          </>
        )}

        {step === 1 && (
          <>
            <h2>2 · Power it and join its Wi‑Fi</h2>
            <ol className="wizard-list">
              <li>Power the board (USB charger or PC). Its blue light blinks fast.</li>
              <li>On your phone, open Wi‑Fi settings and join the network <b>HomeNode‑xxxxxx</b> (no password). If the phone says “no internet”, choose <b>Stay connected</b>.</li>
              <li>A setup page opens by itself. If not, open <span className="mono">http://192.168.4.1</span> in the phone’s browser.</li>
            </ol>
            <p className="small muted">Don’t see HomeNode‑…? Press <b>RST</b> on the board, then hold <b>FLASH</b> for 3 seconds while it blinks fast.</p>
            <div className="row"><button className="btn btn-primary" onClick={() => setStep(2)}>I see the setup page</button></div>
          </>
        )}

        {step === 2 && (
          <>
            <h2>3 · Fill in the setup page</h2>
            <p>Tap <b>Configure WiFi</b>, choose your home Wi‑Fi (2.4 GHz) and type its password. Then fill in these fields exactly:</p>
            {!info && !error && <p className="row muted"><Spinner /> Loading…</p>}
            {info && (
              <table className="table setup-table">
                <tbody>
                  <tr><th>Server address</th><td>{info.server ? <Copy value={info.server} /> : <span className="text-bad">Unknown — set PUBLIC_API_URL in .env</span>}</td></tr>
                  <tr><th>Port</th><td><Copy value={String(info.port)} /></td></tr>
                  <tr><th>Board login</th><td><Copy value={info.login} /></td></tr>
                  <tr><th>Board password</th><td>{info.password ? <Copy value={info.password} secret /> : <span className="text-bad">MQTT_NODE_PASSWORD is not set</span>}</td></tr>
                  <tr><th>Encrypted</th><td className="mono">{info.encrypted ? 'yes' : 'no'}</td></tr>
                </tbody>
              </table>
            )}
            <p className="small muted">Tap <b>Save</b>. The board joins your Wi‑Fi and its blue light goes dark when it reaches this server. Windows must allow port {info?.port ?? 1883} (Help → Boards).</p>
            <div className="row"><button className="btn btn-primary" onClick={() => setStep(3)}>Saved, find my board</button></div>
          </>
        )}

        {step === 3 && (
          <>
            <h2>4 · Find the board</h2>
            {pending.length === 0 ? (
              <div className="wizard-wait">
                <Spinner size={28} />
                <b>Waiting for the board to connect…</b>
                <span className="small muted">Usually under 30 seconds after Save. Still nothing after a minute? Check the server address and password on the setup page (hold FLASH after RST to open it again), and the Windows firewall.</span>
                <button className="btn btn-small" onClick={() => void post('/nodes/scan').then(() => nodes.reload())}>Look again</button>
              </div>
            ) : pending.map((n) => (
              <form key={n.id} className={`subtle-box stack ${known.has(n.id) ? '' : 'found-new'}`} onSubmit={(e) => void adopt(e, n)}>
                <div className="spread">
                  <b>{known.has(n.id) ? 'Board found' : '🎉 New board found'} <span className="mono small muted">{n.id}</span></b>
                  <span className={`badge ${n.online ? 'ok' : 'warn'}`}>{n.online ? 'connected' : 'offline'}</span>
                </div>
                <div className="form-grid">
                  <label className="field">Give it a name<input name="name" required maxLength={60} placeholder="Living room switchboard" autoFocus /></label>
                  <label className="field">Which board is it?
                    <select name="board" defaultValue={n.board}>{catalog.data?.boards.map((b) => <option key={b.type} value={b.type}>{b.name}</option>)}</select>
                  </label>
                </div>
                <button className="btn btn-primary" style={{ alignSelf: 'flex-start' }}>Add to my home</button>
              </form>
            ))}
          </>
        )}
        {error && <div className="alert">{error}</div>}
      </div>
    </div>
  );
}
