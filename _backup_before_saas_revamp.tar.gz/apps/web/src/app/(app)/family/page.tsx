'use client';
import { FormEvent, useState } from 'react';
import { del, errorText, patch, post, put } from '@/lib/api';
import { useLoad } from '@/lib/hooks';
import { useSession } from '@/lib/session';
import type { Access, FamilyMember, Role, Room } from '@/lib/types';
import { Loader } from '@/components/Loader';
import { PageHelp, Tip } from '@/components/Help';

const ROLE_HELP: Record<Role, string> = {
  OWNER: 'Everything, including admins',
  ADMIN: 'Everything: boards, pins, rooms, family',
  MEMBER: 'Only the rooms you give them',
  GUEST: 'Only the rooms you give them, never edit',
};
const ROLE_SHORT: Record<Role, string> = {
  OWNER: 'Owner', ADMIN: 'Admin (everything)', MEMBER: 'Member (chosen rooms)', GUEST: 'Guest (chosen rooms)',
};

export default function FamilyPage() {
  const { me } = useSession();
  const users = useLoad<FamilyMember[]>('/users');
  const rooms = useLoad<Room[]>('/rooms');
  const invites = useLoad<{ id: string; email: string; role: Role; expiresAt: string }[]>('/invites');
  const [link, setLink] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const run = async (fn: () => Promise<unknown>) => {
    setError(null);
    try { await fn(); await Promise.all([users.reload(), invites.reload()]); } catch (err) { setError(errorText(err)); }
  };

  async function invite(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    const f = new FormData(form);
    await run(async () => {
      const res = await post<{ path: string }>('/invites', { email: f.get('email'), role: f.get('role') });
      setLink(`${window.location.origin}${res.path}`);
      form.reset();
    });
  }

  const setAccess = (u: FamilyMember, roomId: string, access: Access | '') => {
    const others = u.rooms.filter((r) => r.roomId !== roomId);
    return run(() => put(`/users/${u.id}/rooms`, { rooms: access ? [...others, { roomId, access }] : others }));
  };
  const roles: Role[] = me.role === 'OWNER' ? ['ADMIN', 'MEMBER', 'GUEST'] : ['MEMBER', 'GUEST'];

  return (
    <>
      <div className="page-head">
        <div>
          <h1>Family</h1>
          <p className="muted">Who can sign in, and what each person may do in each room.</p>
        </div>
        <PageHelp id="family" title="Sharing your home">
          <ul>
            <li><b>Invite</b> creates a link — send it by WhatsApp or SMS. The person picks their own password.</li>
            <li><b>Owner</b> and <b>Admin</b> can change everything. <b>Member</b> and <b>Guest</b> only use the rooms you allow.</li>
            <li>For each room choose <b>No access</b>, <b>See</b> (read only) or <b>Control</b> (switch things).</li>
          </ul>
        </PageHelp>
      </div>

      <section className="card card-pad stack">
        <h2>Invite someone</h2>
        <form className="form-grid" onSubmit={invite}>
          <label className="field">Email<input name="email" type="email" required /></label>
          <label className="field">Role
            <select name="role" defaultValue="MEMBER">
              {roles.map((r) => <option key={r} value={r}>{ROLE_SHORT[r]}</option>)}
            </select>
          </label>
          <button className="btn btn-primary">Create invite link</button>
        </form>
        {link && (
          <div className="subtle-box stack" style={{ gap: 8 }}>
            <span className="small muted">Send this link to them (valid 7 days, works once):</span>
            <div className="row" style={{ flexWrap: 'nowrap' }}>
              <input readOnly value={link} className="mono" onFocus={(e) => e.currentTarget.select()} />
              <button className="btn" onClick={() => navigator.clipboard?.writeText(link)}>Copy</button>
            </div>
          </div>
        )}
        {invites.data && invites.data.length > 0 && (
          <div className="stack" style={{ gap: 6 }}>
            <h3>Waiting to join</h3>
            {invites.data.map((i) => (
              <div key={i.id} className="spread small">
                <span>{i.email} · {i.role.toLowerCase()} · until {new Date(i.expiresAt).toLocaleDateString()}</span>
                <button className="btn btn-small btn-danger" onClick={() => run(() => del(`/invites/${i.id}`))}>Cancel</button>
              </div>
            ))}
          </div>
        )}
      </section>

      {error && <div className="alert section">{error}</div>}

      <section className="section stack">
        {!users.data && !users.error && <Loader label="Loading family…" />}
        {users.data?.map((u) => {
          const editable = u.id !== me.id && (me.role === 'OWNER' || (u.role !== 'OWNER' && u.role !== 'ADMIN'));
          const roomBased = u.role === 'MEMBER' || u.role === 'GUEST';
          return (
            <div key={u.id} className="card card-pad stack">
              <div className="spread">
                <div>
                  <h3>{u.name}{u.id === me.id && <span className="muted"> (you)</span>}</h3>
                  <span className="small muted">{u.email}</span>
                </div>
                <div className="row">
                  {u.disabled && <span className="badge bad">Disabled</span>}
                  {editable ? (
                    <select value={u.role} style={{ width: 'auto' }}
                            onChange={(e) => run(() => patch(`/users/${u.id}`, { role: e.target.value }))}>
                      {[...roles, ...(roles.includes(u.role) ? [] : [u.role])].map((r) => <option key={r} value={r}>{r.toLowerCase()}</option>)}
                    </select>
                  ) : (
                    <span className="badge">{u.role.toLowerCase()}</span>
                  )}
                  {editable && (
                    <>
                      <button className="btn btn-small" onClick={() => run(() => patch(`/users/${u.id}`, { disabled: !u.disabled }))}>
                        {u.disabled ? 'Enable' : 'Disable'}
                      </button>
                      <button className="btn btn-small btn-danger" onClick={() => {
                        if (confirm(`Remove ${u.name}'s account?`)) void run(() => del(`/users/${u.id}`));
                      }}>Remove</button>
                    </>
                  )}
                </div>
              </div>
              {roomBased ? (
                <div className="table-wrap">
                  <table className="table">
                    <tbody>
                      {rooms.data?.map((room) => {
                        const current = u.rooms.find((r) => r.roomId === room.id)?.access ?? '';
                        return (
                          <tr key={room.id}>
                            <td>{room.name}</td>
                            <td style={{ width: 260 }}>
                              <select value={current} disabled={!editable}
                                      onChange={(e) => setAccess(u, room.id, e.target.value as Access | '')}>
                                <option value="">No access</option>
                                <option value="VIEW">Can see</option>
                                <option value="CONTROL">Can switch</option>
                                {u.role === 'MEMBER' && <option value="MANAGE">Can switch and rename</option>}
                              </select>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              ) : (
                <p className="small muted">{ROLE_HELP[u.role]}.</p>
              )}
            </div>
          );
        })}
      </section>
    </>
  );
}
