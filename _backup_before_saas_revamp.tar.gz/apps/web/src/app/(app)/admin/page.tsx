'use client';
import { useEffect, useState } from 'react';
import { Icon } from '@/components/Icon';
import { Loader } from '@/components/Loader';
import { errorText, get } from '@/lib/api';
import { timeAgo } from '@/lib/hooks';
import { useSession } from '@/lib/session';

interface Overview {
  generatedAt: string;
  services: {
    api: { ok: boolean; uptimeSec: number; node: string; memoryMb: number; heapMb: number };
    database: { ok: boolean; ms: number; size: string | null; error: string | null };
    broker: { ok: boolean; url: string };
    assistant: { ok: boolean; ms: number; llm: string | null; error: string | null };
    scheduler: { ok: boolean; active: number; scenes: number; next: { name: string; nextRunAt: string } | null };
  };
  counts: { homes: number; users: Record<string, number>; boards: { total: number; online: number; pending: number }; devices: Record<string, number> };
  commands24h: { total: number; acked: number; failed: number; timeout: number; pending: number; byChannel: Record<string, number> };
  failures: { at: string; status: string; error: string | null; channel: string; device: string; board: string; home: string; by: string | null }[];
  homes: { id: string; name: string; timezone: string; owner: string; ownerEmail: string; users: number; boards: number; rooms: number }[];
  boards: { id: string; name: string; home: string; status: string; online: boolean; lastSeenAt: string | null; firmware: string | null; rssi: number | null; devices: number; configOk: boolean; vcc: number | null; heap: number | null; uptime: number | null }[];
  audit: { at: string; action: string; home: string; by: string; details: Record<string, unknown> }[];
}
interface Hour { hour: string; ok: number; bad: number }

const sum = (o: Record<string, number>) => Object.values(o).reduce((a, b) => a + b, 0);
function dur(sec: number) {
  const d = Math.floor(sec / 86400), h = Math.floor((sec % 86400) / 3600), m = Math.floor((sec % 3600) / 60);
  return d ? `${d}d ${h}h` : h ? `${h}h ${m}m` : `${m}m`;
}

function Service({ icon, name, ok, lines }: { icon: string; name: string; ok: boolean; lines: (string | null | false | undefined)[] }) {
  return (
    <div className={`svc ${ok ? 'ok' : 'bad'}`}>
      <div className="spread">
        <span className="svc-icon"><Icon name={icon} size={17} /></span>
        <span className={`badge ${ok ? 'ok' : 'bad'}`}>{ok ? 'Up' : 'Down'}</span>
      </div>
      <b>{name}</b>
      {lines.filter(Boolean).map((l, i) => <span key={i} className="muted small">{l}</span>)}
    </div>
  );
}

/** Commands per hour: green = confirmed by the board, red = failed / no answer. */
function ActivityChart({ hours }: { hours: Hour[] }) {
  const slots: Hour[] = [];
  const now = new Date();
  now.setMinutes(0, 0, 0);
  for (let i = 23; i >= 0; i--) {
    const t = new Date(now.getTime() - i * 3600000);
    const found = hours.find((h) => new Date(h.hour).getTime() === t.getTime());
    slots.push(found ?? { hour: t.toISOString(), ok: 0, bad: 0 });
  }
  const max = Math.max(1, ...slots.map((s) => s.ok + s.bad));
  return (
    <div className="chart">
      <div className="chart-bars">
        {slots.map((s) => (
          <div key={s.hour} className="chart-col" title={`${new Date(s.hour).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}: ${s.ok} ok, ${s.bad} failed`}>
            <span className="bar-bad" style={{ height: `${(s.bad / max) * 100}%` }} />
            <span className="bar-ok" style={{ height: `${(s.ok / max) * 100}%` }} />
          </div>
        ))}
      </div>
      <div className="chart-axis"><span>24 h ago</span><span>12 h ago</span><span>now</span></div>
    </div>
  );
}

export default function AdminPage() {
  const { me } = useSession();
  const [data, setData] = useState<Overview | null>(null);
  const [hours, setHours] = useState<Hour[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let alive = true;
    const load = () => Promise.all([get<Overview>('/admin/overview'), get<Hour[]>('/admin/activity?hours=24')])
      .then(([o, h]) => { if (alive) { setData(o); setHours(h); setError(null); } })
      .catch((e) => alive && setError(errorText(e)));
    void load();
    const t = setInterval(load, 15000);
    return () => { alive = false; clearInterval(t); };
  }, []);

  if (!me.superAdmin) return <div className="empty">This page is for the platform’s super admins.</div>;
  if (!data) return error ? <div className="alert">{error}</div> : <Loader label="Loading the platform overview…" />;

  const s = data.services;
  const c = data.commands24h;
  const success = c.total ? Math.round((c.acked / c.total) * 100) : 100;
  const kpis = [
    { label: 'Homes', value: data.counts.homes, icon: 'house' },
    { label: 'Users', value: sum(data.counts.users), sub: Object.entries(data.counts.users).map(([r, n]) => `${n} ${r.toLowerCase()}`).join(' · '), icon: 'users' },
    { label: 'Boards online', value: `${data.counts.boards.online}/${data.counts.boards.total}`, sub: data.counts.boards.pending ? `${data.counts.boards.pending} waiting to be added` : undefined, icon: 'cpu', tone: data.counts.boards.online < data.counts.boards.total ? 'warn' : 'ok' },
    { label: 'Devices', value: sum(data.counts.devices), sub: Object.entries(data.counts.devices).map(([t, n]) => `${n} ${t}`).join(' · '), icon: 'lightbulb' },
    { label: 'Commands (24 h)', value: c.total, sub: Object.entries(c.byChannel).map(([ch, n]) => `${n} ${ch}`).join(' · '), icon: 'activity' },
    { label: 'Success rate', value: `${success}%`, sub: `${c.failed + c.timeout} failed or unanswered`, icon: 'shield', tone: success >= 95 ? 'ok' : success >= 80 ? 'warn' : 'bad' },
  ];
  const down = [s.database.ok, s.broker.ok, s.assistant.ok].filter((x) => !x).length;

  return (
    <div className="admin">
      <div className="page-head">
        <div>
          <h1>Super admin</h1>
          <p className="muted">The whole platform at a glance · refreshed {timeAgo(data.generatedAt)}, every 15 seconds.</p>
        </div>
        <span className={`badge ${down ? 'bad' : 'ok'}`}>{down ? `${down} service${down > 1 ? 's' : ''} down` : 'All systems running'}</span>
      </div>
      {error && <div className="alert section">Refresh failed: {error}</div>}

      <section className="section">
        <h2 className="admin-h">Services</h2>
        <div className="svc-grid">
          <Service icon="server" name="API server" ok={s.api.ok} lines={[`Up ${dur(s.api.uptimeSec)} · Node ${s.api.node}`, `Memory ${s.api.memoryMb} MB (heap ${s.api.heapMb} MB)`]} />
          <Service icon="database" name="Database" ok={s.database.ok} lines={[s.database.ok ? `Answers in ${s.database.ms} ms` : s.database.error, s.database.size && `Size ${s.database.size}`]} />
          <Service icon="radio" name="MQTT broker" ok={s.broker.ok} lines={[s.broker.ok ? 'API connected' : 'API cannot reach the broker', s.broker.url]} />
          <Service icon="mic" name="Voice assistant" ok={s.assistant.ok} lines={[s.assistant.ok ? `Answers in ${s.assistant.ms} ms` : 'Not reachable — start apps/assistant', s.assistant.llm && `AI: ${s.assistant.llm}`]} />
          <Service icon="clock" name="Scheduler" ok={s.scheduler.ok} lines={[`${s.scheduler.active} active timers/schedules · ${s.scheduler.scenes} scenes`, s.scheduler.next?.nextRunAt && `Next: ${s.scheduler.next.name} at ${new Date(s.scheduler.next.nextRunAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`]} />
        </div>
      </section>

      <section className="section">
        <div className="stats">
          {kpis.map((k) => (
            <div key={k.label} className={`stat health-${k.tone ?? ''}`}>
              <div className="spread"><span className="stat-label">{k.label}</span><span className="chip tone-ac"><Icon name={k.icon} size={15} /></span></div>
              <div className="stat-value health-value">{k.value}</div>
              {k.sub && <span className="small muted">{k.sub}</span>}
            </div>
          ))}
        </div>
      </section>

      <section className="section card card-pad stack">
        <div className="spread"><h2>Commands per hour</h2><span className="small muted"><i className="lg ok" /> confirmed <i className="lg bad" /> failed</span></div>
        <ActivityChart hours={hours} />
      </section>

      <section className="section">
        <h2 className="admin-h">Boards ({data.boards.length})</h2>
        <div className="table-wrap">
          <table className="table">
            <thead><tr><th /><th>Board</th><th>Home</th><th>Firmware</th><th>Signal</th><th>Voltage</th><th>Memory</th><th>Up</th><th>Last seen</th><th>Settings</th></tr></thead>
            <tbody>
              {data.boards.map((b) => (
                <tr key={b.id}>
                  <td><span className={`dot ${b.online ? 'on' : 'off'}`} title={b.online ? 'Online' : 'Offline'} /></td>
                  <td><b>{b.name}</b><div className="mono small muted">{b.id}</div></td>
                  <td>{b.home}</td>
                  <td className="mono small">{b.firmware ?? '—'}</td>
                  <td className={b.rssi !== null && b.rssi < -80 ? 'text-warn' : ''}>{b.rssi !== null ? `${b.rssi} dBm` : '—'}</td>
                  <td className={b.vcc !== null && b.vcc < 3000 ? 'text-bad' : ''}>{b.vcc !== null ? `${(b.vcc / 1000).toFixed(2)} V` : '—'}</td>
                  <td className={b.heap !== null && b.heap < 8000 ? 'text-bad' : ''}>{b.heap !== null ? `${(b.heap / 1024).toFixed(0)} KB` : '—'}</td>
                  <td>{b.uptime !== null ? dur(b.uptime) : '—'}</td>
                  <td className="small">{b.status === 'PENDING' ? <span className="badge warn">not added</span> : timeAgo(b.lastSeenAt)}</td>
                  <td>{b.status === 'PENDING' ? '—' : b.configOk ? <span className="badge ok">saved</span> : <span className="badge warn">pending</span>}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <div className="admin-two">
        <section className="section">
          <h2 className="admin-h">Recent failed commands</h2>
          <div className="admin-list">
            {data.failures.length === 0 && <div className="empty">No failures. 🎉</div>}
            {data.failures.map((f, i) => (
              <div key={i} className="admin-row">
                <span className={`badge ${f.status === 'TIMEOUT' ? 'warn' : 'bad'}`}>{f.status === 'TIMEOUT' ? 'no answer' : 'failed'}</span>
                <div className="stack-tight">
                  <b>{f.device} <span className="muted small">· {f.board} · {f.home}</span></b>
                  <span className="small muted">{f.error ?? '—'} · {f.channel}{f.by ? ` by ${f.by}` : ''} · {timeAgo(f.at)}</span>
                </div>
              </div>
            ))}
          </div>
        </section>

        <section className="section">
          <h2 className="admin-h">Homes ({data.homes.length})</h2>
          <div className="admin-list">
            {data.homes.map((h) => (
              <div key={h.id} className="admin-row">
                <span className="chip tone-on"><Icon name="house" size={15} /></span>
                <div className="stack-tight">
                  <b>{h.name}</b>
                  <span className="small muted">Owner {h.owner} · {h.users} people · {h.boards} boards · {h.rooms} rooms · {h.timezone}</span>
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>

      <section className="section">
        <h2 className="admin-h">Audit log</h2>
        <div className="admin-list">
          {data.audit.map((a, i) => (
            <div key={i} className="admin-row">
              <span className="mono small audit-action">{a.action}</span>
              <div className="stack-tight">
                <span className="small"><b>{a.by}</b> · {a.home}</span>
                <span className="small muted mono truncate">{JSON.stringify(a.details)}</span>
              </div>
              <span className="small muted" style={{ marginLeft: 'auto', whiteSpace: 'nowrap' }}>{timeAgo(a.at)}</span>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
