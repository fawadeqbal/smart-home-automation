'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { NotificationBell, NoticeToasts } from '@/components/NotificationBell';
import { AppInstall } from '@/components/AppInstall';
import { Icon, toggleTheme } from '@/components/Icon';
import { ScheduleNotices } from '@/components/ScheduleNotices';
import { LiveProvider, useLiveStatus } from '@/lib/live';
import { NotificationsProvider } from '@/lib/notifications';
import { SessionProvider, useSession } from '@/lib/session';

function initials(name: string) {
  return name.split(/\s+/).filter(Boolean).slice(0, 2).map((w) => w[0]!.toUpperCase()).join('') || '?';
}

function ThemeButton({ className = 'icon-btn' }: { className?: string }) {
  return (
    <button className={className} onClick={toggleTheme} aria-label="Switch light or dark mode" title="Light / dark">
      <Icon name="sun" size={16} />
    </button>
  );
}

function Shell({ children }: { children: React.ReactNode }) {
  const { me, isAdmin, logout } = useSession();
  const live = useLiveStatus();
  const path = usePathname();
  const links = [
    { href: '/', label: 'Home', icon: 'house' },
    { href: '/automations', label: 'Automations', icon: 'clock' },
    ...(isAdmin
      ? [
          { href: '/boards', label: 'Boards', icon: 'cpu' },
          { href: '/rooms', label: 'Rooms', icon: 'door-open' },
          { href: '/family', label: 'Family', icon: 'users' },
        ]
      : []),
    ...(me.superAdmin ? [{ href: '/admin', label: 'Super admin', icon: 'shield' }] : []),
    { href: '/help', label: 'Help', icon: 'help' },
  ];
  const active = (href: string) => (href === '/' ? path === '/' : path.startsWith(href));
  const role = me.role.charAt(0) + me.role.slice(1).toLowerCase();

  return (
    <div className="shell">
      <nav className="sidebar" aria-label="Main">
        <div className="brand-row">
          <Link href="/" className="brand">
            <span className="brand-mark"><Icon name="toggle-right" size={16} stroke={2} /></span>Switchboard
          </Link>
          <NotificationBell />
        </div>
        <div className="home-chip">
          <span className="home-chip-icon"><Icon name="house" size={16} /></span>
          <div className="stack-tight"><b>{me.home.name}</b><span className="muted small">Your home</span></div>
        </div>
        <div className="nav-label">Menu</div>
        {links.map((l) => (
          <Link key={l.href} href={l.href} className={`nav-link ${active(l.href) ? 'active' : ''}`}>
            <Icon name={l.icon} />{l.label}
          </Link>
        ))}
        <AppInstall />
        <div className="sidebar-foot">
          <span className={`live ${live ? 'on' : 'off'}`}><span className="live-dot" />{live ? 'Live connection' : 'Reconnecting…'}</span>
          <div className="user-row">
            <span className="avatar">{initials(me.name)}</span>
            <div className="stack-tight" style={{ flex: 1, minWidth: 0 }}><b className="truncate">{me.name}</b><span className="muted small">{role}</span></div>
            <ThemeButton />
            <button className="icon-btn" onClick={logout} aria-label="Sign out" title="Sign out"><Icon name="log-out" size={16} /></button>
          </div>
        </div>
      </nav>

      <div className="main-col">
        <header className="mobile-bar">
          <span className="brand-mark small-mark"><Icon name="toggle-right" size={15} stroke={2} /></span>
          <b>{me.home.name}</b>
          <span className={`live-dot ${live ? 'on' : 'off'}`} title={live ? 'Live' : 'Reconnecting…'} />
          <span className="push" />
          <NotificationBell className="icon-btn icon-btn-lg" />
          <ThemeButton className="icon-btn icon-btn-lg" />
          <button className="avatar" onClick={logout} title="Sign out" aria-label="Sign out">{initials(me.name)}</button>
        </header>
        <main className="main">{children}</main>
        <NoticeToasts />
        <ScheduleNotices userId={me.id} isAdmin={isAdmin} />
        {links.length > 1 && (
          <nav className="tabbar" aria-label="Main">
            {links.map((l) => (
              <Link key={l.href} href={l.href} className={`tab ${active(l.href) ? 'active' : ''}`}>
                <Icon name={l.icon} size={20} />{l.label}
              </Link>
            ))}
          </nav>
        )}
      </div>
    </div>
  );
}

export default function AppLayout({ children }: { children: React.ReactNode }) {
  return (
    <SessionProvider>
      <LiveProvider>
        <NotificationsProvider>
          <Shell>{children}</Shell>
        </NotificationsProvider>
      </LiveProvider>
    </SessionProvider>
  );
}
