'use client';
import Link from 'next/link';
import { AssistantPanel } from '@/components/AssistantPanel';
import { DeviceCard } from '@/components/DeviceCard';
import { useDevices } from '@/lib/hooks';
import { useSession } from '@/lib/session';
import type { Device } from '@/lib/types';
import { Icon } from '@/components/Icon';
import { Loader } from '@/components/Loader';
import { PageHelp, Tip } from '@/components/Help';

function groupByRoom(devices: Device[]) {
  const groups = new Map<string, Device[]>();
  for (const d of devices) {
    const room = d.roomName ?? 'No room';
    groups.set(room, [...(groups.get(room) ?? []), d]);
  }
  return [...groups.entries()];
}

export default function HomePage() {
  const { me, isAdmin } = useSession();
  const { devices, error, replace } = useDevices();
  const onCount = devices?.filter((d) => d.controllable && d.online && d.state?.on).length ?? 0;
  const offline = devices?.filter((d) => !d.online).length ?? 0;
  const temps = (devices ?? []).map((d) => d.state?.temperature).filter((t): t is number => typeof t === 'number');
  const hour = new Date().getHours();
  const greeting = hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening';
  const stats = devices
    ? [
        { label: 'On now', value: String(onCount), icon: 'lightbulb', tone: 'on' },
        { label: 'Devices', value: String(devices.length), icon: 'cpu', tone: 'ac' },
        { label: 'Offline', value: String(offline), icon: 'toggle-right', tone: offline ? 'bad' : 'ok' },
        ...(temps.length
          ? [{ label: 'Temperature', value: (temps.reduce((a, b) => a + b, 0) / temps.length).toFixed(1), unit: '°C', icon: 'thermometer', tone: 'ok' }]
          : []),
      ]
    : [];

  return (
    <>
      <div className="page-head">
        <div>
          <h1>{greeting}, {me.name.split(' ')[0]}</h1>
          <p className="muted">
            {devices ? `${onCount} on${offline ? ` · ${offline} offline` : ''}` : 'Loading devices…'}
          </p>
        </div>
        <PageHelp id="home" title="Your home at a glance">
          <ul>
            <li><b>Tap a tile</b> to switch that light or socket on or off. Amber means on.</li>
            <li><b>Talk or type</b> to the assistant: “turn off the kitchen light”, “is the door open?”.</li>
            <li><b>Grey tiles</b> are offline — the wall switch still works; it reconnects by itself.</li>
            <li><b>View history</b> shows who switched it and when, or a sensor’s readings.</li>
          </ul>
        </PageHelp>
      </div>

      {stats.length > 0 && (
        <div className="stats">
          {stats.map((st) => (
            <div className="stat" key={st.label}>
              <div className="spread"><span className="stat-label">{st.label}</span><span className={`chip tone-${st.tone}`}><Icon name={st.icon} size={15} /></span></div>
              <div className="stat-value">{st.value}{'unit' in st && <span className="stat-unit">{st.unit}</span>}</div>
            </div>
          ))}
        </div>
      )}

      <AssistantPanel />

      {!devices && !error && <Loader label="Loading devices…" />}
      {error && <div className="alert section">{error}</div>}
      {devices && devices.length === 0 && (
        <div className="empty section">
          {isAdmin ? (
            <>No devices yet. Go to <Link href="/boards">Boards</Link> to adopt a board and add a bulb or sensor.</>
          ) : (
            <>No rooms have been shared with you yet. Ask the home owner to give you access.</>
          )}
        </div>
      )}
      {devices &&
        groupByRoom(devices).map(([room, list]) => (
          <section className="section" key={room}>
            <div className="section-head">
              <h2>{room}</h2>
              <span className="pill">
                {list.length} device{list.length === 1 ? '' : 's'}
                {list.some((d) => d.controllable && d.online && d.state?.on) ? ` · ${list.filter((d) => d.controllable && d.online && d.state?.on).length} on` : ''}
              </span>
            </div>
            <div className="grid-cards">
              {list.map((d) => <DeviceCard key={d.id} device={d} onChange={replace} />)}
            </div>
          </section>
        ))}
    </>
  );
}
