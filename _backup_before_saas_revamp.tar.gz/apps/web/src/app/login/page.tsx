'use client';
import { useRouter } from 'next/navigation';
import { useEffect } from 'react';
import { AuthForm, Field } from '@/components/AuthForm';
import { get, post } from '@/lib/api';

export default function LoginPage() {
  const router = useRouter();

  useEffect(() => {
    get<{ setupNeeded: boolean }>('/auth/status')
      .then((s) => s.setupNeeded && router.replace('/setup'))
      .catch(() => undefined);
  }, [router]);

  return (
    <AuthForm
      title="Sign in"
      intro="Welcome home."
      submitLabel="Sign in"
      onSubmit={async (f) => {
        await post('/auth/login', { email: f.get('email'), password: f.get('password') });
        router.replace('/');
      }}
    >
      <Field label="Email" name="email" type="email" autoComplete="email" required autoFocus />
      <Field label="Password" name="password" type="password" autoComplete="current-password" required />
    </AuthForm>
  );
}
