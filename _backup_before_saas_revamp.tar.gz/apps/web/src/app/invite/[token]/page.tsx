'use client';
import { useParams, useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import { AuthForm, Field } from '@/components/AuthForm';
import { errorText, get, post } from '@/lib/api';
import { Loader } from '@/components/Loader';

export default function InvitePage() {
  const { token } = useParams<{ token: string }>();
  const router = useRouter();
  const [invite, setInvite] = useState<{ email: string; role: string; homeName: string } | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    get<{ email: string; role: string; homeName: string }>(`/invites/${token}`).then(setInvite).catch((e) => setError(errorText(e)));
  }, [token]);

  if (error) {
    return (
      <main className="auth-solo">
        <div className="card card-pad auth-card"><h1>Invite</h1><div className="alert" style={{ marginTop: 16 }}>{error}</div></div>
      </main>
    );
  }
  if (!invite) return <Loader full label="Opening your invite…" />;

  return (
    <AuthForm
      title={`Join ${invite.homeName}`}
      intro={<>You were invited as <b>{invite.role.toLowerCase()}</b> with {invite.email}. Choose your name and a password.</>}
      submitLabel="Join"
      onSubmit={async (f) => {
        await post(`/invites/${token}/accept`, { name: f.get('name'), password: f.get('password') });
        router.replace('/');
      }}
    >
      <Field label="Your name" name="name" autoComplete="name" required autoFocus />
      <Field label="Password (8+ characters)" name="password" type="password" minLength={8} autoComplete="new-password" required />
    </AuthForm>
  );
}
