# Home platform

Control your home from a web app and by voice. ESP8266 boards drive the bulbs and read the sensors; family members sign in with their own rights; everything runs on your PC now and moves to a cloud server later with the same files.

```
 Browser / phone ──HTTPS──►  Next.js web (3000) ──/api──►  NestJS API (4000) ──Prisma──► PostgreSQL
                                                              │  ▲
                                         voice + tool calls   │  │ MQTT
                                                              ▼  │
                                              Python voice service (8000)     Mosquitto (1883) ◄──MQTT── ESP8266 boards
```

| Folder | What | Tech |
|---|---|---|
| `apps/api` | The only writer to the database and the only broker client: sign-in, rights, boards, devices, commands with acknowledgement, history, live updates | NestJS 11, Prisma 6, mqtt.js, Socket.IO |
| `apps/web` | Dashboard, voice assistant, boards and pins, rooms, family | Next.js 15, React 19 |
| `apps/assistant` | Speech to text, the AI with device tools (acting with the speaker's rights), text to speech | Python, FastAPI, faster-whisper, Ollama or Claude, Piper |
| `firmware/home_node` | One firmware for every board; devices and pins come from the web app | ESP8266 Arduino, PubSubClient, WiFiManager |
| `packages/contracts` | The shared language: MQTT topics and payloads, board pin rules, device types | TypeScript + zod |
| `infra` | Docker Compose (Postgres, Mosquitto; cloud: Traefik + all apps), broker config | |
| `tools/fake-node` | A pretend board speaking the same MQTT protocol, to test without hardware | Python |

---

## Run it on your Windows PC

### 1. Install once

- **Docker Desktop** (with WSL 2) — runs Postgres and Mosquitto
- **Node.js 22 LTS** — then in a terminal: `npm install -g pnpm`
- **Python 3.11+** (you already have it for the old assistant)
- **Ollama** with a model (`ollama pull qwen2.5:3b`), or a Claude API key
- **Arduino IDE 2** for the board (see `firmware/README.md`)

### 2. Settings

```powershell
cd home-platform
copy .env.example .env
notepad .env        # change every "change-me" (passwords, JWT_SECRET, ASSISTANT_SHARED_SECRET)
```

Make the database password in `DATABASE_URL` match `POSTGRES_PASSWORD`.

### 3. Database, broker, API and web

```powershell
pnpm install
pnpm infra:up       # Postgres + Mosquitto in Docker
pnpm db:deploy      # create the tables
pnpm dev            # API on :4000 and web on :3000, reloading on every save
```

### 4. Voice assistant (second terminal)

```powershell
cd apps\assistant
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
copy ..\..\..\pi-voice-assistant\voices\en_US-lessac-medium.onnx* models\    # your Piper voice
python -m assistant.main
```

### 5. Use it

1. Open **http://localhost:3000** → create your home and owner account.
2. **No board yet?** Third terminal: `pip install paho-mqtt` then `python tools\fake-node\fake_node.py`. Type `press D5` in it to "press the wall button".
3. **Boards** → adopt the board → **Add device**: *Bulb*, Switch, D1 → **Add device**: *Room climate*, DHT22, D2 → **Add wall button**: D5 toggles Bulb.
4. **Home** → tap the bulb, or tap the mic / type *"turn on the bulb"*, *"what is the temperature?"*.
5. **Family** → create an invite link, open it in another browser, give that person *Can switch* on a room.

The real board: flash `firmware/home_node` and follow `firmware/README.md` (setup page: server = your PC's IP, port 1883, login `node`, password `MQTT_NODE_PASSWORD`, encrypted `no`).

**From your phone on the home Wi‑Fi:** open `http://<your-PC-IP>:3000` and add that address to `WEB_ORIGIN` in `.env` (comma separated) for live updates. Tapping works; the **microphone needs HTTPS**, so on the phone voice works once it runs in the cloud with your domain (on the PC, `localhost` counts as secure).

### Everything in Docker instead

```powershell
pnpm infra:all      # builds and runs postgres, mosquitto, api, web, assistant, adminer (:8081)
```

The assistant container reaches Ollama on your PC through `host.docker.internal`.

---

## Tests

```powershell
pnpm test                                   # contracts + API unit tests
pnpm --filter @home/api test:e2e            # full flow with a fake board: needs `pnpm infra:up`, stop `pnpm dev` first; EMPTIES the database
cd apps\assistant; python -m pytest         # voice service
```

The end-to-end test runs the real API, database and broker with a fake board and a live-update client: setup, board discovery, adoption, pin validation, acknowledged commands, sensor readings, family rights, the wall button, and a board going offline.

---

## How the parts talk

**Boards ↔ server: MQTT** (`packages/contracts/src/topics.ts`)

| Topic `home/v1/nodes/{nodeId}/…` | From → to | Retained | Payload |
|---|---|---|---|
| `status` | board → all | yes | `{"online":true,"fw","ip"}`; the broker's Last Will sets `{"online":false}` |
| `announce` | board → server | yes | `{"board","fw","mac","ip"}` — lists the board under New boards |
| `config` | server → board | yes | `{"rev","adopted","devices":[{key,type,pin,activeLow,settings}],"inputs":[…]}` |
| `config/applied` | board → server | no | `{"rev","ok","error?"}` |
| `devices/{key}/set` | server → board | **no** | `{"cid","on":true}` |
| `devices/{key}/state` | board → all | yes | `{"on":true,"src":"remote","cid"}` or `{"temperature","humidity","src":"sensor"}` |
| `telemetry` | board → server | no | `{"rssi","heap","uptime"}` |
| `cmd` | server → board | no | `{"action":"reboot"}` |

Each board logs in as `node` with its node id as MQTT client id; the broker lets it use only its own topics (`infra/mosquitto/acl`).

**Apps ↔ server: REST + Socket.IO** at `/api` and `/socket.io`. Sign-in uses httpOnly cookies (15‑minute access token, rotating 30‑day refresh token). The voice service is called only by the API, with a shared secret and a 2‑minute token for the person speaking, which its device tools send back to the API — so voice can never do more than that person could in the app.

**Rights:** owner and admins do everything; members and guests get *Can see*, *Can switch* or (members) *Can switch and rename* per room. Devices without a room are visible to owners and admins only.

---

## Adding things

| To add… | Change |
|---|---|
| A device on a board | Web app → Boards → Add device. No code. |
| A new kind of device (dimmer, curtain, PIR) | `packages/contracts/src/device-types.ts` (type, pin use, settings schema, state fields) + a `Device` subclass and one line in `firmware/home_node/src/devices/DeviceFactory.cpp`. The API, web forms, cards and assistant pick it up from the catalog |
| A tool for the assistant | A `Tool` subclass in `apps/assistant/assistant/tools.py`, added in `build_tools()` |
| An API feature | A controller + service in `apps/api/src/<feature>/`, registered in `app.module.ts`; schema changes in `prisma/schema.prisma` then `pnpm db:migrate` |
| A Python service | `apps/<name>/` shaped like `apps/assistant`, calling the API with its own token |

## Going to the cloud

1. A VM with Docker, a domain with DNS for `home.your-domain` and `mqtt.home.your-domain` pointing at it.
2. Copy the repository and `.env`; set `DOMAIN`, `ACME_EMAIL`, `WEB_ORIGIN=https://<DOMAIN>`, `COOKIE_SECURE=true`.
3. `docker compose --env-file .env -f infra/docker-compose.yml --profile cloud up -d --build`
4. On each board's setup page: server `mqtt.<DOMAIN>`, port `8883`, encrypted `yes`.

Traefik gets the certificates; only ports 80, 443 and 8883 are open.
